from __future__ import annotations

import argparse
import gzip
import io
import json
import os
import struct
import sys
import tempfile
from pathlib import Path
from typing import BinaryIO

import numpy as np
import pandas as pd
import streamlit as st
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import plotly.graph_objects as go
except ModuleNotFoundError:  # pragma: no cover - optional visualization dependency
    go = None


APP_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = Path(os.environ.get("GCGF_OUTPUT_ROOT", APP_DIR)).resolve()
TRAINING_CODE_DIR = Path(os.environ.get("GCGF_TRAINING_CODE_DIR", APP_DIR)).resolve()
if str(TRAINING_CODE_DIR) not in sys.path:
    sys.path.insert(0, str(TRAINING_CODE_DIR))

try:
    import adni_backbone_training_common as training_common
except Exception as exc:  # pragma: no cover - Streamlit displays this during startup
    training_common = None
    TRAINING_IMPORT_ERROR = exc
else:
    TRAINING_IMPORT_ERROR = None

MODEL_ROOT = Path(os.environ.get("GCGF_MODEL_ROOT", APP_DIR / "checkpoints" / "top5")).resolve()
FOLD_DIRS = [MODEL_ROOT / f"top5_fold{i}" for i in range(5)]
TARGET_SHAPE = (169, 208, 179)
PREDICTION_ENDPOINT = "MCI-to-AD progression"
PREDICTION_HORIZON = "36 months / 3 years"
ALL_CLINICAL_COLUMNS = [
    "AGE",
    "Gender",
    "APOE4",
    "PTEDUCAT",
    "MMSE",
    "ADAS11",
    "CDRSB",
    "ADAS13",
    "RAVLT_immediate",
    "RAVLT_learning",
    "RAVLT_forgetting",
    "RAVLT_perc_forgetting",
    "LDELTOTAL",
    "FAQ",
]
TOP5_COLUMNS = ["FAQ", "APOE4", "RAVLT_immediate", "CDRSB", "LDELTOTAL"]
CLINICAL_DISPLAY_NAMES = {
    "FAQ": "FAQ",
    "APOE4": "APOE4 count",
    "RAVLT_immediate": "RAVLT immediate",
    "CDRSB": "CDR-SB",
    "LDELTOTAL": "Logical memory delayed",
}
CLINICAL_GROUPS = {
    "demo": ["AGE", "Gender", "APOE4", "PTEDUCAT"],
    "global": ["MMSE", "ADAS11", "ADAS13", "CDRSB"],
    "memory": [
        "RAVLT_immediate",
        "RAVLT_learning",
        "RAVLT_forgetting",
        "RAVLT_perc_forgetting",
        "LDELTOTAL",
    ],
    "func": ["FAQ"],
}


class DenseLayer3D(nn.Module):
    def __init__(self, in_channels: int, growth_rate: int, bn_size: int, drop_rate: float):
        super().__init__()
        inter_channels = bn_size * growth_rate
        self.norm1 = nn.BatchNorm3d(in_channels)
        self.conv1 = nn.Conv3d(in_channels, inter_channels, kernel_size=1, stride=1, bias=False)
        self.norm2 = nn.BatchNorm3d(inter_channels)
        self.conv2 = nn.Conv3d(inter_channels, growth_rate, kernel_size=3, stride=1, padding=1, bias=False)
        self.drop_rate = drop_rate

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.conv1(F.relu(self.norm1(x), inplace=True))
        out = self.conv2(F.relu(self.norm2(out), inplace=True))
        if self.drop_rate > 0:
            out = F.dropout(out, p=self.drop_rate, training=self.training)
        return torch.cat([x, out], dim=1)


class DenseBlock3D(nn.Module):
    def __init__(self, num_layers: int, in_channels: int, growth_rate: int, bn_size: int, drop_rate: float):
        super().__init__()
        self.layers = nn.ModuleList()
        channels = in_channels
        for _ in range(num_layers):
            self.layers.append(DenseLayer3D(channels, growth_rate, bn_size, drop_rate))
            channels += growth_rate

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x)
        return x


def transition(in_channels: int, out_channels: int) -> nn.Sequential:
    return nn.Sequential(
        nn.BatchNorm3d(in_channels),
        nn.ReLU(inplace=True),
        nn.Conv3d(in_channels, out_channels, kernel_size=1, stride=1, bias=False),
        nn.AvgPool3d(kernel_size=2, stride=2),
    )


class DenseNet1213D(nn.Module):
    def __init__(
        self,
        growth_rate: int = 32,
        block_config: tuple[int, int, int, int] = (6, 12, 24, 16),
        init_features: int = 64,
        bn_size: int = 4,
        drop_rate: float = 0.0,
        compression: float = 0.5,
    ):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv3d(1, init_features, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm3d(init_features),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(kernel_size=3, stride=2, padding=1),
        )
        channels = init_features
        self.block1 = DenseBlock3D(block_config[0], channels, growth_rate, bn_size, drop_rate)
        channels += block_config[0] * growth_rate
        out_channels = int(channels * compression)
        self.trans1 = transition(channels, out_channels)
        channels = out_channels

        self.block2 = DenseBlock3D(block_config[1], channels, growth_rate, bn_size, drop_rate)
        channels += block_config[1] * growth_rate
        out_channels = int(channels * compression)
        self.trans2 = transition(channels, out_channels)
        channels = out_channels

        self.block3 = DenseBlock3D(block_config[2], channels, growth_rate, bn_size, drop_rate)
        channels += block_config[2] * growth_rate
        out_channels = int(channels * compression)
        self.trans3 = transition(channels, out_channels)
        self.stage3_channels = channels
        channels = out_channels

        self.block4 = DenseBlock3D(block_config[3], channels, growth_rate, bn_size, drop_rate)
        channels += block_config[3] * growth_rate
        self.norm5 = nn.BatchNorm3d(channels)
        self.out_channels = channels

    def forward_to_stage3(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.block1(x)
        x = self.trans1(x)
        x = self.block2(x)
        x = self.trans2(x)
        x = self.block3(x)
        return x

    def forward_from_stage3(self, x: torch.Tensor) -> torch.Tensor:
        x = self.trans3(x)
        x = self.block4(x)
        x = F.relu(self.norm5(x), inplace=True)
        return x


class GroupMLP(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int = 128, out_dim: int = 64, dropout: float = 0.25):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class GroupAwareClinicalEncoder(nn.Module):
    def __init__(self, hidden_dim: int = 128, group_embed_dim: int = 64, clinical_dim: int = 256, dropout: float = 0.25):
        super().__init__()
        self.mlp_demo = GroupMLP(4, hidden_dim, group_embed_dim, dropout)
        self.mlp_global = GroupMLP(4, hidden_dim, group_embed_dim, dropout)
        self.mlp_memory = GroupMLP(5, hidden_dim, group_embed_dim, dropout)
        self.mlp_func = GroupMLP(1, hidden_dim, group_embed_dim, dropout)
        self.fusion = nn.Sequential(
            nn.Linear(group_embed_dim * 4, clinical_dim),
            nn.LayerNorm(clinical_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(clinical_dim, clinical_dim),
            nn.LayerNorm(clinical_dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, clinical: torch.Tensor) -> torch.Tensor:
        idx = {name: i for i, name in enumerate(ALL_CLINICAL_COLUMNS)}
        demo = clinical[:, [idx[c] for c in CLINICAL_GROUPS["demo"]]]
        global_ = clinical[:, [idx[c] for c in CLINICAL_GROUPS["global"]]]
        memory = clinical[:, [idx[c] for c in CLINICAL_GROUPS["memory"]]]
        func = clinical[:, [idx[c] for c in CLINICAL_GROUPS["func"]]]
        return self.fusion(
            torch.cat(
                [
                    self.mlp_demo(demo),
                    self.mlp_global(global_),
                    self.mlp_memory(memory),
                    self.mlp_func(func),
                ],
                dim=1,
            )
        )


class FiLM(nn.Module):
    def __init__(self, channels: int = 1024, clinical_dim: int = 256):
        super().__init__()
        self.gamma = nn.Sequential(nn.Linear(clinical_dim, 128), nn.ReLU(inplace=True), nn.Linear(128, channels))
        self.beta = nn.Sequential(nn.Linear(clinical_dim, 128), nn.ReLU(inplace=True), nn.Linear(128, channels))

    def forward(self, x: torch.Tensor, clinical_embedding: torch.Tensor) -> torch.Tensor:
        gamma = self.gamma(clinical_embedding).view(x.size(0), x.size(1), 1, 1, 1)
        beta = self.beta(clinical_embedding).view(x.size(0), x.size(1), 1, 1, 1)
        return x * (1.0 + gamma) + beta


class SpatialAttention(nn.Module):
    def __init__(self, channels: int = 1024, clinical_dim: int = 256):
        super().__init__()
        self.clinical_proj = nn.Linear(clinical_dim, channels)
        self.attention = nn.Sequential(
            nn.Conv3d(channels, 256, kernel_size=1, bias=False),
            nn.BatchNorm3d(256),
            nn.ReLU(inplace=True),
            nn.Conv3d(256, 1, kernel_size=3, padding=1, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor, clinical_embedding: torch.Tensor) -> torch.Tensor:
        clinical_map = self.clinical_proj(clinical_embedding).view(x.size(0), x.size(1), 1, 1, 1)
        attn = self.attention(x + clinical_map)
        return x * attn


class ClinicalGuidedDenseNet121(nn.Module):
    def __init__(self, dropout: float = 0.25):
        super().__init__()
        self.backbone = DenseNet1213D()
        self.clinical_encoder = GroupAwareClinicalEncoder(dropout=dropout)
        self.film3 = FiLM()
        self.spatial3 = SpatialAttention()
        self.film4 = FiLM()
        self.spatial4 = SpatialAttention()
        self.classifier = nn.Sequential(
            nn.Linear(1280, 256),
            nn.LayerNorm(256),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(256, 1),
        )

    def forward(self, mri: torch.Tensor, clinical: torch.Tensor) -> torch.Tensor:
        clinical_embedding = self.clinical_encoder(clinical)
        x = self.backbone.forward_to_stage3(mri)
        x = self.spatial3(self.film3(x, clinical_embedding), clinical_embedding)
        x = self.backbone.forward_from_stage3(x)
        x = self.spatial4(self.film4(x, clinical_embedding), clinical_embedding)
        pooled = F.adaptive_avg_pool3d(x, output_size=1).flatten(1)
        return self.classifier(torch.cat([pooled, clinical_embedding], dim=1)).squeeze(1)


def _read_nifti_fallback(file_obj: BinaryIO | bytes | str | Path) -> np.ndarray:
    if isinstance(file_obj, (str, Path)):
        path = Path(file_obj)
        data = gzip.open(path, "rb").read() if "".join(path.suffixes).endswith(".nii.gz") else path.read_bytes()
    elif isinstance(file_obj, bytes):
        data = gzip.decompress(file_obj) if file_obj[:2] == b"\x1f\x8b" else file_obj
    else:
        raw = file_obj.read()
        data = gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw

    endian = "<"
    sizeof_hdr = struct.unpack("<i", data[:4])[0]
    if sizeof_hdr != 348:
        endian = ">"
        sizeof_hdr = struct.unpack(">i", data[:4])[0]
    if sizeof_hdr != 348:
        raise ValueError("Not a NIfTI-1 file: sizeof_hdr is not 348.")

    dim = struct.unpack(endian + "8h", data[40:56])
    shape = tuple(int(d) for d in dim[1 : 1 + dim[0]])
    datatype = struct.unpack(endian + "h", data[70:72])[0]
    vox_offset = int(struct.unpack(endian + "f", data[108:112])[0])
    slope = struct.unpack(endian + "f", data[112:116])[0]
    inter = struct.unpack(endian + "f", data[116:120])[0]
    dtype_map = {
        2: np.uint8,
        4: np.int16,
        8: np.int32,
        16: np.float32,
        64: np.float64,
        256: np.int8,
        512: np.uint16,
        768: np.uint32,
        1024: np.int64,
        1280: np.uint64,
    }
    if datatype not in dtype_map:
        raise ValueError(f"Unsupported NIfTI datatype code: {datatype}")
    dtype = np.dtype(dtype_map[datatype]).newbyteorder(endian)
    arr = np.frombuffer(data, dtype=dtype, offset=vox_offset, count=int(np.prod(shape)))
    arr = arr.reshape(shape, order="F").astype(np.float32)
    if slope not in (0.0, 1.0):
        arr = arr * slope
    if inter != 0.0:
        arr = arr + inter
    return np.asarray(arr, dtype=np.float32)


def load_nifti(file_or_path) -> np.ndarray:
    try:
        import nibabel as nib  # type: ignore

        if isinstance(file_or_path, (str, Path)):
            return np.asarray(nib.load(str(file_or_path)).get_fdata(dtype=np.float32), dtype=np.float32)
        with tempfile.NamedTemporaryFile(suffix=".nii.gz", delete=True) as tmp:
            tmp.write(file_or_path.getvalue())
            tmp.flush()
            return np.asarray(nib.load(tmp.name).get_fdata(dtype=np.float32), dtype=np.float32)
    except ModuleNotFoundError:
        if hasattr(file_or_path, "getvalue"):
            return _read_nifti_fallback(file_or_path.getvalue())
        return _read_nifti_fallback(file_or_path)


def preprocess_mri(volume: np.ndarray) -> torch.Tensor:
    volume = np.asarray(volume, dtype=np.float32)
    volume = np.squeeze(volume)
    volume = np.nan_to_num(volume, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)

    nonzero = volume[np.abs(volume) > 1e-6]
    if nonzero.size > 50:
        lo, hi = np.percentile(nonzero, [0.5, 99.5])
        volume = np.clip(volume, lo, hi)
        clipped_nonzero = volume[np.abs(volume) > 1e-6]
        mean = float(clipped_nonzero.mean())
        std = float(clipped_nonzero.std())
    else:
        mean = float(volume.mean())
        std = float(volume.std())

    if not np.isfinite(std) or std < 1e-6:
        std = 1.0
    volume = (volume - mean) / std

    x = torch.from_numpy(volume[None, None, ...].copy())
    if tuple(volume.shape) != TARGET_SHAPE:
        x = F.interpolate(x, size=TARGET_SHAPE, mode="trilinear", align_corners=False)
    return x.float()


def build_clinical_tensor(values: dict[str, float], normalizer: dict) -> torch.Tensor:
    normalized = []
    for col in ALL_CLINICAL_COLUMNS:
        if col in TOP5_COLUMNS:
            stats = normalizer[col]
            std = float(stats.get("std") or 1.0)
            raw = float(values[col])
            normalized.append((raw - float(stats["mean"])) / std if std > 1e-8 else 0.0)
        else:
            normalized.append(0.0)
    return torch.tensor([normalized], dtype=torch.float32)


def build_densenet121_full_model(dropout: float = 0.25) -> nn.Module:
    if training_common is None:
        raise ImportError(
            f"Could not import training model code from {TRAINING_CODE_DIR}. "
            f"Original error: {TRAINING_IMPORT_ERROR}"
        )

    args = argparse.Namespace(
        group_embed_dim=64,
        clinical_dim=256,
        clinical_hidden_dim=128,
        classifier_hidden_dim=256,
        dropout=dropout,
        resnet_base_channels=64,
        densenet_growth_rate=32,
        densenet_init_features=64,
        densenet_bn_size=4,
        densenet_drop_rate=0.0,
        densenet_compression=0.5,
        convnext_dims=[48, 96, 192, 384],
        convnext_depths=[3, 3, 9, 3],
        convnext_use_checkpoint=False,
        drop_path_rate=0.1,
        swin_embed_dim=24,
        swin_patch_size=[4, 4, 4],
        swin_window_size=[7, 7, 7],
        swin_depths=[2, 2, 2, 2],
        swin_num_heads=[3, 6, 12, 24],
        swin_use_checkpoint=False,
    )
    return training_common.build_model("full", "densenet121", args)


@st.cache_resource(show_spinner=False)
def load_ensemble():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    models = []
    thresholds = []
    normalizers = []
    load_messages = []
    for fold_dir in FOLD_DIRS:
        ckpt_path = fold_dir / "best_full_clinical_guided_densenet121.pt"
        ckpt = torch.load(ckpt_path, map_location=device)
        model = build_densenet121_full_model(dropout=0.25).to(device)
        missing, unexpected = model.load_state_dict(ckpt["model_state_dict"], strict=True)
        model.eval()
        models.append(model)
        thresholds.append(float(ckpt.get("decision_threshold", ckpt.get("val_metrics", {}).get("threshold", 0.5))))
        normalizers.append(ckpt.get("clinical_normalizer"))
        load_messages.append({"fold": fold_dir.name, "missing": len(missing), "unexpected": len(unexpected)})
    return models, float(np.mean(thresholds)), normalizers, device, load_messages


def predict(mri_tensor: torch.Tensor, clinical_values: dict[str, float]) -> tuple[float, list[float], float]:
    models, threshold, normalizers, device, _ = load_ensemble()
    probs = []
    with torch.inference_mode():
        mri_tensor = mri_tensor.to(device)
        for model, normalizer in zip(models, normalizers):
            clinical = build_clinical_tensor(clinical_values, normalizer).to(device)
            logits = model(mri_tensor, clinical)
            probs.append(float(torch.sigmoid(logits).cpu().item()))
    return float(np.mean(probs)), probs, threshold


def inject_enterprise_css() -> None:
    st.markdown(
        """
        <style>
        :root {
            --page: #e8edf1;
            --panel: #f6f8fa;
            --panel-strong: #edf2f5;
            --panel-border: #c9d4dc;
            --ink: #17212c;
            --muted: #596a78;
            --navy: #102331;
            --navy-2: #16364a;
            --teal: #006f7a;
            --teal-soft: #dcecef;
            --amber: #8a6200;
            --rose: #9f314d;
            --rose-soft: #f0dce2;
            --green: #1c6b50;
            --green-soft: #dcece6;
        }
        .stApp {
            background: var(--page);
            color: var(--ink);
        }
        [data-testid="stSidebar"],
        [data-testid="collapsedControl"] {
            display: none;
        }
        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, var(--navy) 0%, #0c1a25 100%);
            border-right: 1px solid rgba(255, 255, 255, 0.08);
        }
        [data-testid="stSidebar"] h1,
        [data-testid="stSidebar"] h2,
        [data-testid="stSidebar"] h3,
        [data-testid="stSidebar"] p,
        [data-testid="stSidebar"] span,
        [data-testid="stSidebar"] label {
            color: #f3f7fa;
        }
        [data-testid="stSidebar"] div[data-testid="stMetric"] {
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(255, 255, 255, 0.14);
        }
        [data-testid="stHeader"] {
            background: rgba(232, 237, 241, 0.92);
            backdrop-filter: blur(12px);
        }
        .block-container {
            padding-top: 1.15rem;
            padding-bottom: 2rem;
            padding-left: 1.25rem;
            padding-right: 1.25rem;
            max-width: 1880px;
        }
        h1, h2, h3, h4, h5, h6, p, label, span {
            color: var(--ink);
        }
        div[data-testid="stMetric"],
        div[data-testid="stDataFrame"],
        div[data-testid="stPlotlyChart"],
        div[data-testid="stImage"] {
            border-radius: 8px;
        }
        div[data-testid="stMetric"] {
            background: var(--panel);
            border: 1px solid var(--panel-border);
            box-shadow: none;
            padding: 0.82rem 0.92rem;
        }
        div[data-testid="stMetricLabel"] p {
            color: var(--muted);
            font-size: 0.76rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0;
        }
        div[data-testid="stMetricValue"] {
            color: var(--ink);
            font-weight: 800;
        }
        .app-shell {
            display: grid;
            grid-template-columns: 1fr;
            gap: 0.85rem;
        }
        .clinical-header {
            background: linear-gradient(90deg, var(--navy) 0%, var(--navy-2) 100%);
            border: 1px solid rgba(13, 38, 54, 0.28);
            border-radius: 8px;
            padding: 1rem 1.2rem;
            margin-bottom: 0.85rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }
        .clinical-header h1 {
            color: #f4f8fb;
            font-size: 1.52rem;
            line-height: 1.16;
            margin: 0;
            letter-spacing: 0;
        }
        .clinical-header .subtitle {
            color: #c8d8e2;
            margin-top: 0.22rem;
            font-size: 0.86rem;
        }
        .header-status {
            display: flex;
            gap: 0.45rem;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .status-pill {
            border: 1px solid rgba(255, 255, 255, 0.18);
            background: rgba(255, 255, 255, 0.10);
            border-radius: 6px;
            padding: 0.38rem 0.58rem;
            color: #edf5f8;
            font-size: 0.78rem;
            font-weight: 650;
        }
        div[data-testid="stVerticalBlockBorderWrapper"] {
            background: var(--panel);
            border: 1px solid var(--panel-border);
            border-radius: 8px;
            box-shadow: none;
        }
        .clinical-note {
            background: var(--teal-soft);
            border: 1px solid rgba(0, 111, 122, 0.20);
            border-radius: 8px;
            padding: 0.72rem 0.82rem;
            color: #073840;
            font-size: 0.84rem;
            line-height: 1.45;
            margin-top: 0.6rem;
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 0.55rem;
            margin: 0.15rem 0 0.7rem;
            color: var(--ink);
            font-size: 0.98rem;
            font-weight: 800;
        }
        .section-title:before {
            content: "";
            width: 0.32rem;
            height: 1.05rem;
            border-radius: 2px;
            background: var(--teal);
        }
        .status-strip {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 0.65rem;
            margin-bottom: 0.85rem;
        }
        .status-item {
            background: var(--panel-strong);
            border: 1px solid var(--panel-border);
            border-radius: 8px;
            padding: 0.72rem 0.82rem;
        }
        .status-item span {
            display: block;
            color: var(--muted);
            font-size: 0.74rem;
            font-weight: 750;
            text-transform: uppercase;
        }
        .status-item strong {
            display: block;
            color: var(--ink);
            font-size: 0.98rem;
            margin-top: 0.28rem;
        }
        .result-panel {
            border-radius: 8px;
            border: 1px solid var(--panel-border);
            background: var(--panel);
            padding: 1rem;
        }
        .risk-positive {
            color: #7f1830;
            background: var(--rose-soft);
            border: 1px solid rgba(159, 49, 77, 0.28);
            border-radius: 8px;
            padding: 0.78rem 0.9rem;
            font-weight: 800;
        }
        .risk-negative {
            color: #13543f;
            background: var(--green-soft);
            border: 1px solid rgba(28, 107, 80, 0.25);
            border-radius: 8px;
            padding: 0.78rem 0.9rem;
            font-weight: 800;
        }
        .risk-borderline {
            color: #684b00;
            background: #efe7d1;
            border: 1px solid rgba(138, 98, 0, 0.28);
            border-radius: 8px;
            padding: 0.78rem 0.9rem;
            font-weight: 800;
        }
        .report-box {
            background: var(--panel-strong);
            border: 1px solid var(--panel-border);
            border-radius: 8px;
            padding: 0.9rem;
            color: var(--ink);
            line-height: 1.55;
        }
        .report-box strong {
            color: var(--ink);
        }
        .small-note {
            color: var(--muted);
            font-size: 0.82rem;
            line-height: 1.55;
        }
        .clinical-disclaimer {
            color: #5a3f00;
            background: #efe7d1;
            border: 1px solid rgba(138, 98, 0, 0.25);
            border-radius: 8px;
            padding: 0.72rem 0.82rem;
            font-size: 0.84rem;
            line-height: 1.45;
        }
        .stButton > button {
            border-radius: 8px;
            border: 1px solid #a9bac5;
            color: var(--ink);
            background: #edf2f5;
            font-weight: 750;
        }
        .stButton > button[kind="primary"],
        .stButton > button[data-testid="baseButton-primary"] {
            background: var(--teal);
            border-color: var(--teal);
            color: #f3fbfc;
        }
        .stDownloadButton > button {
            border-radius: 8px;
            border: 1px solid var(--teal);
            background: #dcecef;
            color: #06343a;
            font-weight: 750;
        }
        .stFileUploader, .stTextInput, .stNumberInput {
            color: var(--ink);
        }
        .stTabs [data-baseweb="tab-list"] {
            gap: 0.25rem;
            border-bottom: 1px solid var(--panel-border);
        }
        .stTabs [data-baseweb="tab"] {
            border-radius: 8px 8px 0 0;
            padding: 0.68rem 0.95rem;
            font-weight: 750;
            color: var(--ink);
        }
        .stTabs [aria-selected="true"] {
            background: var(--panel);
            border: 1px solid var(--panel-border);
            border-bottom: 0;
        }
        @media (max-width: 900px) {
            .status-strip {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
            .clinical-header {
                align-items: flex-start;
                flex-direction: column;
            }
            .clinical-header h1 {
                font-size: 1.26rem;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def panel_title(text: str) -> None:
    st.markdown(f'<div class="section-title">{text}</div>', unsafe_allow_html=True)


def source_ready(uploaded, mri_path: str) -> bool:
    return uploaded is not None or bool(mri_path.strip())


def read_source_volume(uploaded, mri_path: str) -> np.ndarray:
    source = uploaded if uploaded is not None else Path(mri_path.strip())
    return load_nifti(source)


def display_slice(image: np.ndarray) -> np.ndarray:
    image = np.asarray(image, dtype=np.float32)
    image = np.nan_to_num(image)
    lo, hi = np.percentile(image, [1, 99])
    if hi <= lo:
        lo, hi = float(image.min()), float(image.max())
    if hi <= lo:
        return np.rot90(np.zeros_like(image, dtype=np.float32))
    image = np.clip((image - lo) / (hi - lo), 0.0, 1.0)
    return np.rot90(image)


def volume_stats(volume: np.ndarray) -> dict[str, str]:
    finite = np.asarray(volume[np.isfinite(volume)], dtype=np.float32)
    nonzero = finite[finite != 0]
    basis = nonzero if nonzero.size else finite
    return {
        "Shape": " x ".join(str(v) for v in volume.shape),
        "Non-zero voxels": f"{nonzero.size:,}",
        "Mean": f"{float(basis.mean()):.4f}" if basis.size else "NA",
        "Std": f"{float(basis.std()):.4f}" if basis.size else "NA",
        "P1/P99": f"{np.percentile(basis, 1):.2f} / {np.percentile(basis, 99):.2f}" if basis.size else "NA",
    }


def render_status_strip(volume: np.ndarray | None, threshold: float, device: torch.device, result: dict | None) -> None:
    shape = "Not loaded" if volume is None else " x ".join(str(v) for v in volume.shape)
    prob = "Pending" if not result else f"{result['prob']:.4f}"
    label = "Pending"
    if result:
        label = "pMCI / positive" if result["prob"] >= result["threshold"] else "sMCI / negative"
    st.markdown(
        f"""
        <div class="status-strip">
          <div class="status-item"><span>MRI volume</span><strong>{shape}</strong></div>
          <div class="status-item"><span>Runtime</span><strong>{device}</strong></div>
          <div class="status-item"><span>Decision threshold</span><strong>{threshold:.4f}</strong></div>
          <div class="status-item"><span>Ensemble output</span><strong>{prob} | {label}</strong></div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_orthogonal_views(volume: np.ndarray) -> None:
    panel_title("MRI 正交切面浏览")
    x_mid, y_mid, z_mid = volume.shape[0] // 2, volume.shape[1] // 2, volume.shape[2] // 2
    c1, c2, c3 = st.columns(3)
    with c1:
        x = st.slider("Sagittal", 0, volume.shape[0] - 1, x_mid)
        st.image(display_slice(volume[x, :, :]), caption=f"Sagittal x={x}", use_column_width=True, clamp=True)
    with c2:
        y = st.slider("Coronal", 0, volume.shape[1] - 1, y_mid)
        st.image(display_slice(volume[:, y, :]), caption=f"Coronal y={y}", use_column_width=True, clamp=True)
    with c3:
        z = st.slider("Axial", 0, volume.shape[2] - 1, z_mid)
        st.image(display_slice(volume[:, :, z]), caption=f"Axial z={z}", use_column_width=True, clamp=True)


def render_mip_views(volume: np.ndarray) -> None:
    panel_title("Maximum Intensity Projection")
    c1, c2, c3 = st.columns(3)
    projections = [
        ("Sagittal MIP", np.max(volume, axis=0)),
        ("Coronal MIP", np.max(volume, axis=1)),
        ("Axial MIP", np.max(volume, axis=2)),
    ]
    for col, (name, image) in zip((c1, c2, c3), projections):
        with col:
            st.image(display_slice(image), caption=name, use_column_width=True, clamp=True)


def render_mosaic(volume: np.ndarray) -> None:
    panel_title("Axial Slice Matrix")
    finite_slices = np.linspace(0.12, 0.88, 16)
    indices = [int(round(p * (volume.shape[2] - 1))) for p in finite_slices]
    images = [display_slice(volume[:, :, idx]) for idx in indices]
    h, w = images[0].shape
    images = [img if img.shape == (h, w) else np.resize(img, (h, w)) for img in images]
    gap = 4
    grid = np.ones((4 * h + 3 * gap, 4 * w + 3 * gap), dtype=np.float32) * 0.03
    for n, image in enumerate(images):
        r, c = divmod(n, 4)
        y0 = r * (h + gap)
        x0 = c * (w + gap)
        grid[y0 : y0 + h, x0 : x0 + w] = image
    st.image(grid, caption="16-slice axial mosaic across the full cranial field", use_column_width=True, clamp=True)


def downsample_volume(volume: np.ndarray, max_points: int = 68) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    steps = tuple(max(1, int(np.ceil(dim / max_points))) for dim in volume.shape)
    vol = volume[:: steps[0], :: steps[1], :: steps[2]]
    vol = np.nan_to_num(vol.astype(np.float32))
    x = np.arange(vol.shape[0]) * steps[0]
    y = np.arange(vol.shape[1]) * steps[1]
    z = np.arange(vol.shape[2]) * steps[2]
    return vol, x, y, z


def render_volume_rendering(volume: np.ndarray) -> None:
    panel_title("3D MRI Volume Rendering")
    if go is None:
        st.info("Plotly is not installed, so 3D volume rendering is skipped. Install `plotly` to enable it.")
        return
    vol, x, y, z = downsample_volume(volume)
    finite = vol[np.isfinite(vol)]
    nonzero = finite[finite != 0]
    basis = nonzero if nonzero.size else finite
    if basis.size == 0:
        st.warning("MRI volume has no finite voxels for 3D rendering.")
        return
    lo, hi = np.percentile(basis, [45, 99.4])
    if hi <= lo:
        lo, hi = float(basis.min()), float(basis.max())
    if hi <= lo:
        st.warning("MRI intensity range is too narrow for 3D rendering.")
        return
    xx, yy, zz = np.meshgrid(x, y, z, indexing="ij")
    fig = go.Figure(
        data=go.Volume(
            x=xx.flatten(),
            y=yy.flatten(),
            z=zz.flatten(),
            value=vol.flatten(),
            isomin=float(lo),
            isomax=float(hi),
            opacity=0.12,
            surface_count=18,
            colorscale=[
                [0.00, "#07111f"],
                [0.35, "#007c89"],
                [0.70, "#d7a83f"],
                [1.00, "#f2f7f7"],
            ],
            caps=dict(x_show=False, y_show=False, z_show=False),
            showscale=False,
        )
    )
    fig.update_layout(
        height=620,
        margin=dict(l=0, r=0, t=0, b=0),
        paper_bgcolor="rgba(0,0,0,0)",
        scene=dict(
            bgcolor="rgba(10, 18, 30, 0.98)",
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            zaxis=dict(visible=False),
            aspectmode="data",
            camera=dict(eye=dict(x=1.65, y=1.55, z=1.15)),
        ),
    )
    st.plotly_chart(fig, use_container_width=True)


def render_histogram(volume: np.ndarray) -> None:
    panel_title("Intensity Distribution")
    finite = volume[np.isfinite(volume)]
    nonzero = finite[finite != 0]
    values = nonzero if nonzero.size else finite
    if values.size == 0:
        st.warning("No finite intensity values found.")
        return
    sample = values if values.size <= 200000 else np.random.default_rng(42).choice(values, size=200000, replace=False)
    counts, bins = np.histogram(sample, bins=90)
    df = pd.DataFrame({"intensity": bins[:-1], "voxel_count": counts})
    if go is not None:
        fig = go.Figure(
            data=go.Bar(
                x=df["intensity"],
                y=df["voxel_count"],
                marker=dict(color="#007c89", line=dict(color="#0f2330", width=0.3)),
                hovertemplate="Intensity %{x:.3f}<br>Voxels %{y}<extra></extra>",
            )
        )
        fig.update_layout(
            height=285,
            margin=dict(l=10, r=10, t=8, b=10),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(255,255,255,0.70)",
            xaxis_title="Intensity",
            yaxis_title="Voxel count",
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.bar_chart(df.set_index("intensity"))


def render_fold_probability_chart(fold_probs: list[float], threshold: float) -> None:
    df = pd.DataFrame({"fold": [f"fold{i}" for i in range(len(fold_probs))], "probability": fold_probs})
    if go is None:
        st.dataframe(df, use_container_width=True)
        return
    colors = ["#a33d58" if p >= threshold else "#007c89" for p in fold_probs]
    fig = go.Figure(
        data=go.Bar(
            x=df["fold"],
            y=df["probability"],
            marker=dict(color=colors),
            text=[f"{p:.3f}" for p in fold_probs],
            textposition="outside",
            hovertemplate="%{x}: %{y:.4f}<extra></extra>",
        )
    )
    fig.add_hline(y=threshold, line_width=2, line_dash="dash", line_color="#a66f00")
    fig.update_layout(
        height=330,
        yaxis=dict(range=[0, 1], title="Probability"),
        xaxis=dict(title="Validation fold"),
        margin=dict(l=15, r=15, t=12, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(255,255,255,0.70)",
        showlegend=False,
    )
    st.plotly_chart(fig, use_container_width=True)


def render_clinical_chart(clinical_values: dict[str, float]) -> None:
    df = pd.DataFrame({"variable": list(clinical_values.keys()), "value": list(clinical_values.values())})
    if go is None:
        st.dataframe(df, use_container_width=True)
        return
    fig = go.Figure(
        data=go.Bar(
            x=df["variable"],
            y=df["value"],
            marker=dict(color=["#007c89", "#a66f00", "#325d79", "#a33d58", "#52616f"]),
            hovertemplate="%{x}: %{y:.3f}<extra></extra>",
        )
    )
    fig.update_layout(
        height=300,
        margin=dict(l=12, r=12, t=8, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(255,255,255,0.70)",
        yaxis_title="Raw clinical value",
        xaxis_title=None,
    )
    st.plotly_chart(fig, use_container_width=True)


def main() -> None:
    st.set_page_config(page_title="DAFN NeuroFusion Console", layout="wide", initial_sidebar_state="expanded")
    inject_enterprise_css()

    with st.sidebar:
        st.markdown("## DAFN Console")
        st.caption("TOP5 clinical-guided 3D DenseNet121 ensemble")
        try:
            _, threshold, _, device, load_messages = load_ensemble()
            st.success(f"5 folds loaded on {device}")
            st.metric("Ensemble threshold", f"{threshold:.4f}")
            with st.expander("Checkpoint load diagnostics"):
                st.dataframe(pd.DataFrame(load_messages), use_container_width=True)
        except Exception as exc:
            st.error(f"Model loading failed: {exc}")
            st.stop()
        st.divider()
        st.caption(f"Model root: {MODEL_ROOT}")

    st.markdown(
        """
        <div class="app-hero">
          <h1>DAFN NeuroFusion Console</h1>
          <p>Enterprise-grade MRI and clinical TOP5 fusion workstation for 5-fold ensemble inference,
          volumetric quality control, and transparent fold-level review.</p>
          <div class="hero-row">
            <span class="hero-chip">3D DenseNet121</span>
            <span class="hero-chip">Clinical-guided FiLM attention</span>
            <span class="hero-chip">TOP5 variables</span>
            <span class="hero-chip">MRI volume cockpit</span>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    volume = st.session_state.get("volume")
    result = st.session_state.get("result")
    render_status_strip(volume, threshold, device, result)

    defaults = {"FAQ": 2.0, "APOE4": 1.0, "RAVLT_immediate": 31.0, "CDRSB": 1.5, "LDELTOTAL": 5.0}
    intake_tab, mri_tab, prediction_tab, audit_tab = st.tabs(
        ["Case Intake", "MRI Workstation", "AI Interpretation", "Model Audit"]
    )

    with intake_tab:
        c1, c2 = st.columns([1.05, 0.95])
        with c1:
            panel_title("MRI 输入")
            uploaded = st.file_uploader("Upload preprocessed MRI (.nii or .nii.gz)", type=["nii", "gz"])
            mri_path = st.text_input("Or enter local preprocessed MRI path", value="")
            st.markdown(
                f'<div class="small-note">The deployed model expects MRI files already aligned, cropped, '
                f'and shaped as {TARGET_SHAPE}. The app applies the same non-zero voxel z-score normalization '
                f'before inference.</div>',
                unsafe_allow_html=True,
            )
        with c2:
            panel_title("TOP5 临床变量")
            clinical_values = {}
            for col in TOP5_COLUMNS:
                clinical_values[col] = st.number_input(col, value=float(defaults[col]), step=0.1, key=f"clinical_{col}")
            render_clinical_chart(clinical_values)

        a1, a2, a3 = st.columns([0.9, 0.9, 2.2])
        with a1:
            load_clicked = st.button("Load MRI Workstation", use_container_width=True)
        with a2:
            infer_clicked = st.button("Run AI Inference", type="primary", use_container_width=True)

        if load_clicked or infer_clicked:
            if not source_ready(uploaded, mri_path):
                st.warning("Please upload a preprocessed MRI file or enter a local path.")
            else:
                try:
                    volume = read_source_volume(uploaded, mri_path)
                    mri_tensor = preprocess_mri(volume)
                    st.session_state["volume"] = volume
                    st.session_state["mri_tensor"] = mri_tensor
                    st.success("MRI loaded and preprocessing validation passed.")
                except Exception as exc:
                    st.error(f"MRI loading failed: {exc}")
                    st.stop()

        if infer_clicked and "mri_tensor" in st.session_state:
            try:
                prob, fold_probs, decision_threshold = predict(st.session_state["mri_tensor"], clinical_values)
                st.session_state["result"] = {
                    "prob": prob,
                    "fold_probs": fold_probs,
                    "threshold": decision_threshold,
                    "clinical_values": clinical_values,
                }
                st.success("Inference complete. Open AI Interpretation for the full review.")
            except Exception as exc:
                st.error(f"Prediction failed: {exc}")
                st.stop()

    with mri_tab:
        volume = st.session_state.get("volume")
        if volume is None:
            st.info("Load an MRI from Case Intake to activate the workstation.")
        else:
            stats = volume_stats(volume)
            s1, s2, s3, s4, s5 = st.columns(5)
            s1.metric("Shape", stats["Shape"])
            s2.metric("Non-zero voxels", stats["Non-zero voxels"])
            s3.metric("Mean", stats["Mean"])
            s4.metric("Std", stats["Std"])
            s5.metric("P1 / P99", stats["P1/P99"])
            render_volume_rendering(volume)
            m1, m2 = st.columns([1.12, 0.88])
            with m1:
                render_orthogonal_views(volume)
                render_mosaic(volume)
            with m2:
                render_mip_views(volume)
                render_histogram(volume)

    with prediction_tab:
        result = st.session_state.get("result")
        if result is None:
            st.info("Run AI Inference from Case Intake to populate this interpretation panel.")
        else:
            prob = float(result["prob"])
            decision_threshold = float(result["threshold"])
            label = "pMCI / positive" if prob >= decision_threshold else "sMCI / negative"
            risk_class = "risk-positive" if prob >= decision_threshold else "risk-negative"
            p1, p2, p3, p4 = st.columns(4)
            p1.metric("Ensemble probability", f"{prob:.4f}")
            p2.metric("Decision threshold", f"{decision_threshold:.4f}")
            p3.metric("Margin", f"{prob - decision_threshold:+.4f}")
            p4.metric("Fold spread", f"{np.std(result['fold_probs']):.4f}")
            st.markdown(f'<div class="{risk_class}">Final ensemble class: {label}</div>', unsafe_allow_html=True)
            st.progress(min(max(prob, 0.0), 1.0))
            b1, b2 = st.columns([1.15, 0.85])
            with b1:
                panel_title("Fold-level Probability Review")
                render_fold_probability_chart(result["fold_probs"], decision_threshold)
            with b2:
                panel_title("Clinical Signal Snapshot")
                render_clinical_chart(result["clinical_values"])
                st.dataframe(
                    pd.DataFrame(
                        {
                            "fold": [f"fold{i}" for i in range(len(result["fold_probs"]))],
                            "probability": result["fold_probs"],
                        }
                    ),
                    use_container_width=True,
                    hide_index=True,
                )

    with audit_tab:
        panel_title("Deployment Integrity")
        c1, c2, c3 = st.columns(3)
        c1.metric("Loaded folds", "5")
        c2.metric("Input shape contract", "169 x 208 x 179")
        c3.metric("Clinical features", "5 / 14")
        st.dataframe(pd.DataFrame(load_messages), use_container_width=True, hide_index=True)
        st.markdown(
            """
            <div class="small-note">
            This interface preserves the training-time MRI contract: users should provide preprocessed NIfTI
            volumes with the same registration/cropping pipeline used during model development. The application
            validates shape and applies non-zero voxel z-score normalization before ensemble inference.
            </div>
            """,
            unsafe_allow_html=True,
        )


def classify_risk(prob: float, threshold: float) -> tuple[str, str]:
    margin = prob - threshold
    if abs(margin) < 0.05:
        return "Borderline", "risk-borderline"
    if margin >= 0:
        return "Higher 3-year AD progression risk", "risk-positive"
    return "Lower 3-year AD progression risk", "risk-negative"


def render_header(model_ready: bool, threshold: float | None) -> None:
    status = "Ready" if model_ready else "Unavailable"
    st.markdown(
        f"""
        <div class="clinical-header">
          <div>
            <h1>NeuroClinFusion-5</h1>
            <div class="subtitle">Decision support for baseline MCI assessment</div>
          </div>
          <div class="header-status">
            <span class="status-pill">Target: {PREDICTION_ENDPOINT}</span>
            <span class="status-pill">Horizon: {PREDICTION_HORIZON}</span>
            <span class="status-pill">Inputs: MRI + 5 variables</span>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_compact_mri_review(volume: np.ndarray) -> None:
    stats = volume_stats(volume)
    s1, s2, s3 = st.columns(3)
    s1.metric("Volume shape", stats["Shape"])
    s2.metric("Non-zero voxels", stats["Non-zero voxels"])
    s3.metric("Intensity P1 / P99", stats["P1/P99"])

    x_mid, y_mid, z_mid = volume.shape[0] // 2, volume.shape[1] // 2, volume.shape[2] // 2
    c1, c2, c3 = st.columns(3)
    with c1:
        st.image(display_slice(volume[x_mid, :, :]), caption="Sagittal midline", use_column_width=True, clamp=True)
    with c2:
        st.image(display_slice(volume[:, y_mid, :]), caption="Coronal midline", use_column_width=True, clamp=True)
    with c3:
        st.image(display_slice(volume[:, :, z_mid]), caption="Axial midline", use_column_width=True, clamp=True)


def _normalize_heatmap(cam: np.ndarray) -> np.ndarray:
    cam = np.nan_to_num(np.asarray(cam, dtype=np.float32), nan=0.0, posinf=0.0, neginf=0.0)
    cam = np.maximum(cam, 0.0)
    positive = cam[cam > 0]
    if positive.size == 0:
        return np.zeros_like(cam, dtype=np.float32)
    hi = float(np.percentile(positive, 99.5))
    if not np.isfinite(hi) or hi <= 1e-8:
        hi = float(positive.max())
    if hi <= 1e-8:
        return np.zeros_like(cam, dtype=np.float32)
    return np.clip(cam / hi, 0.0, 1.0).astype(np.float32)


def brain_mask_from_volume(volume: np.ndarray) -> np.ndarray:
    volume = np.nan_to_num(np.asarray(volume, dtype=np.float32), nan=0.0, posinf=0.0, neginf=0.0)
    mask = np.abs(volume) > 1e-6
    if mask.sum() < 1000:
        finite = volume[np.isfinite(volume)]
        if finite.size == 0:
            return np.zeros_like(volume, dtype=bool)
        threshold = float(np.percentile(np.abs(finite), 20))
        mask = np.abs(volume) > max(threshold, 1e-6)
    return mask


def mask_heatmap_to_brain(heatmap: np.ndarray, volume: np.ndarray) -> np.ndarray:
    heatmap = np.asarray(heatmap, dtype=np.float32)
    mask = brain_mask_from_volume(volume)
    if mask.shape != heatmap.shape:
        mask = np.resize(mask, heatmap.shape)
    masked = np.where(mask, heatmap, 0.0)
    return _normalize_heatmap(masked)


def _model_gradcam(model: nn.Module, mri_tensor: torch.Tensor, clinical_tensor: torch.Tensor) -> np.ndarray:
    model.eval()
    model.zero_grad(set_to_none=True)

    e = model.clinical_encoder(clinical_tensor)
    f3 = model.backbone.forward_to_stage3(mri_tensor)
    f3_film = model.film3(f3, e)
    f3_att, _ = model.spatial3(f3_film, e)
    f4 = model.backbone.forward_stage4(f3_att)
    f4_film = model.film4(f4, e)
    f4_att, _ = model.spatial4(f4_film, e)
    f4_att.retain_grad()

    pooled = model.pool(f4_att).flatten(1)
    logit = model.classifier(torch.cat([pooled, e], dim=1)).squeeze(1)
    logit.sum().backward()

    grads = f4_att.grad
    if grads is None:
        raise RuntimeError("Gradient attribution failed: no gradients were captured.")
    weights = grads.mean(dim=(2, 3, 4), keepdim=True)
    cam = torch.relu((weights * f4_att).sum(dim=1, keepdim=True))
    cam = F.interpolate(cam, size=TARGET_SHAPE, mode="trilinear", align_corners=False)
    return _normalize_heatmap(cam[0, 0].detach().float().cpu().numpy())


def generate_clinical_conditioned_heatmap(mri_tensor: torch.Tensor, clinical_values: dict[str, float]) -> tuple[np.ndarray, int]:
    models, _, normalizers, device, _ = load_ensemble()
    mri_tensor = mri_tensor.to(device)
    n_models = len(models) if device.type == "cuda" else 1
    cams = []
    for model, normalizer in zip(models[:n_models], normalizers[:n_models]):
        clinical = build_clinical_tensor(clinical_values, normalizer).to(device)
        cam = _model_gradcam(model, mri_tensor, clinical)
        cams.append(cam)
        model.zero_grad(set_to_none=True)
        if device.type == "cuda":
            torch.cuda.empty_cache()
    if not cams:
        raise RuntimeError("No heatmap could be generated.")
    return _normalize_heatmap(np.mean(cams, axis=0)), len(cams)


def _model_probability(model: nn.Module, mri_tensor: torch.Tensor, clinical_tensor: torch.Tensor) -> float:
    model.eval()
    with torch.inference_mode():
        logit = model(mri_tensor, clinical_tensor)
        return float(torch.sigmoid(logit).detach().cpu().item())


def _counterfactual_value(column: str, current_values: dict[str, float], normalizer: dict) -> tuple[float, str]:
    if column == "APOE4":
        return 0.0, "APOE4 count -> 0"
    stats = normalizer[column]
    replacement = float(stats.get("mean", current_values[column]))
    return replacement, f"{CLINICAL_DISPLAY_NAMES[column]} -> cohort reference"


def format_clinical_value(column: str, value: float) -> str:
    if column == "APOE4":
        return f"{float(value):.0f}"
    if column in {"FAQ", "RAVLT_immediate", "LDELTOTAL"}:
        return f"{float(value):.0f}"
    return f"{float(value):.1f}"


def generate_clinical_risk_signature(
    mri_tensor: torch.Tensor,
    clinical_values: dict[str, float],
    base_probability: float,
) -> list[dict]:
    models, _, normalizers, device, _ = load_ensemble()
    mri_tensor = mri_tensor.to(device)
    rows = []
    for column in TOP5_COLUMNS:
        cf_probs = []
        reference_labels = []
        for model, normalizer in zip(models, normalizers):
            cf_values = dict(clinical_values)
            replacement, reference_label = _counterfactual_value(column, clinical_values, normalizer)
            cf_values[column] = replacement
            cf_clinical = build_clinical_tensor(cf_values, normalizer).to(device)
            cf_probs.append(_model_probability(model, mri_tensor, cf_clinical))
            reference_labels.append(reference_label)
        cf_mean = float(np.mean(cf_probs))
        delta = float(base_probability - cf_mean)
        rows.append(
            {
                "column": column,
                "variable": CLINICAL_DISPLAY_NAMES[column],
                "value": format_clinical_value(column, clinical_values[column]),
                "reference": reference_labels[0],
                "delta_risk": delta,
                "abs_delta_risk": abs(delta),
            }
        )
    rows.sort(key=lambda item: item["abs_delta_risk"], reverse=True)
    return rows


def _heat_color(heat: np.ndarray) -> np.ndarray:
    h = np.clip(np.asarray(heat, dtype=np.float32), 0.0, 1.0)
    stops = np.array(
        [
            [0.32, 0.00, 0.78],
            [0.10, 0.42, 0.95],
            [0.05, 0.83, 0.86],
            [0.56, 0.92, 0.45],
            [1.00, 0.82, 0.20],
            [0.96, 0.05, 0.04],
        ],
        dtype=np.float32,
    )
    positions = np.linspace(0.0, 1.0, len(stops), dtype=np.float32)
    channels = [np.interp(h, positions, stops[:, i]) for i in range(3)]
    return np.stack(channels, axis=-1)


def append_colorbar(image: np.ndarray) -> np.ndarray:
    h, w, _ = image.shape
    bar_w = max(14, w // 36)
    gap = max(8, w // 80)
    gradient = np.linspace(1.0, 0.0, h, dtype=np.float32)[:, None]
    bar = (_heat_color(gradient) * 255).astype(np.uint8)
    bar = np.repeat(bar, bar_w, axis=1)
    canvas = np.zeros((h, w + gap + bar_w, 3), dtype=np.uint8)
    canvas[:, :w, :] = image
    canvas[:, w + gap :, :] = bar
    return canvas


def _best_slice_index(heatmap: np.ndarray, brain_mask: np.ndarray, axis: int) -> int:
    heat_scores = heatmap.sum(axis=tuple(i for i in range(3) if i != axis))
    mask_scores = brain_mask.sum(axis=tuple(i for i in range(3) if i != axis)).astype(np.float32)
    if mask_scores.max() <= 0:
        return int(heatmap.shape[axis] // 2)
    brain_score = mask_scores / float(mask_scores.max())
    heat_score = heat_scores / float(heat_scores.max() + 1e-8)
    valid = brain_score >= 0.55
    score = (0.68 * heat_score + 0.32 * brain_score) * valid
    if score.max() <= 0:
        score = brain_score
    return int(np.argmax(score))


def heatmap_overlay_slice(volume_slice: np.ndarray, heat_slice: np.ndarray) -> np.ndarray:
    base = display_slice(volume_slice)
    slice_mask = np.abs(np.nan_to_num(np.asarray(volume_slice, dtype=np.float32))) > 1e-6
    heat_slice = np.where(slice_mask, heat_slice, 0.0)
    heat = np.rot90(np.nan_to_num(heat_slice.astype(np.float32)))
    heat = np.clip(heat, 0.0, 1.0)
    if heat.shape != base.shape:
        heat = np.resize(heat, base.shape)
    base_rgb = np.stack([base, base, base], axis=-1) * 0.86
    heat_rgb = _heat_color(heat)
    alpha = np.clip((heat - 0.06) / 0.94, 0.0, 1.0) ** 0.62
    alpha = alpha[..., None] * 0.64
    overlay = np.clip((1.0 - alpha) * base_rgb + alpha * heat_rgb, 0.0, 1.0)
    return (overlay * 255).astype(np.uint8)


def render_heatmap_review(volume: np.ndarray, heatmap: np.ndarray, result: dict | None) -> None:
    heatmap = mask_heatmap_to_brain(heatmap, volume)
    brain_mask = brain_mask_from_volume(volume)
    stats = volume_stats(volume)
    if float(heatmap.max()) <= 1e-8:
        render_compact_mri_review(volume)
        st.info("Heatmap attribution was too weak after brain masking, so standard MRI review is shown.")
        return
    peak = np.unravel_index(int(np.argmax(heatmap)), heatmap.shape)
    x_show = _best_slice_index(heatmap, brain_mask, axis=0)
    y_show = _best_slice_index(heatmap, brain_mask, axis=1)
    z_show = _best_slice_index(heatmap, brain_mask, axis=2)
    s1, s2, s3, s4 = st.columns(4)
    s1.metric("Volume shape", stats["Shape"])
    s2.metric("Non-zero voxels", stats["Non-zero voxels"])
    s3.metric("Attribution peak", f"x{peak[0]} y{peak[1]} z{peak[2]}")
    s4.metric("Attribution mode", "Clinical-conditioned")

    c1, c2, c3 = st.columns(3)
    with c1:
        image = heatmap_overlay_slice(volume[x_show, :, :], heatmap[x_show, :, :])
        st.image(
            append_colorbar(image),
            caption=f"Sagittal risk-attribution overlay, x={x_show}",
            use_column_width=True,
        )
    with c2:
        image = heatmap_overlay_slice(volume[:, y_show, :], heatmap[:, y_show, :])
        st.image(
            append_colorbar(image),
            caption=f"Coronal risk-attribution overlay, y={y_show}",
            use_column_width=True,
        )
    with c3:
        image = heatmap_overlay_slice(volume[:, :, z_show], heatmap[:, :, z_show])
        st.image(
            append_colorbar(image),
            caption=f"Axial risk-attribution overlay, z={z_show}",
            use_column_width=True,
        )

    if result is not None:
        values = result["clinical_values"]
        apoe = f"{float(values['APOE4']):.0f}"
        st.markdown(
            f"""
            <div class="report-box">
            <strong>Clinical-conditioned interpretation:</strong> the displayed MRI heatmap is generated after conditioning the model on
            FAQ {float(values['FAQ']):.0f}, APOE4 count {apoe}, RAVLT immediate {float(values['RAVLT_immediate']):.0f},
            CDR-SB {float(values['CDRSB']):.1f}, and logical memory delayed {float(values['LDELTOTAL']):.0f}.
            Warmer brain regions indicate stronger contribution to the predicted {PREDICTION_HORIZON} AD progression risk and should not be interpreted as lesion localization.
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_clinical_risk_signature(signature_items: list[dict]) -> None:
    if not signature_items:
        return
    panel_title("Clinical Risk Signature")
    st.markdown(
        """
        <div class="report-box">
        The MRI heatmap above is conditioned on the current 5-variable clinical profile. The signature below shows how each
        clinical variable shifts the predicted 3-year AD progression risk relative to a reference setting while the MRI is kept unchanged.
        </div>
        """,
        unsafe_allow_html=True,
    )
    max_abs = max(float(item["abs_delta_risk"]) for item in signature_items) or 1.0
    for item in signature_items:
        delta = float(item["delta_risk"])
        width = max(4.0, min(100.0, abs(delta) / max_abs * 100.0))
        color = "#a63a52" if delta >= 0 else "#006f7a"
        direction = "increases risk" if delta >= 0 else "decreases risk"
        st.markdown(
            f"""
            <div style="border:1px solid #c9d4dc;border-radius:8px;padding:0.72rem 0.82rem;margin-top:0.55rem;background:#edf2f5;">
              <div style="display:flex;justify-content:space-between;gap:1rem;align-items:baseline;">
                <div style="font-weight:800;color:#17212c;">{item['variable']}</div>
                <div style="font-weight:800;color:{color};">{delta:+.4f}</div>
              </div>
              <div style="font-size:0.82rem;color:#596a78;margin-top:0.1rem;">
                Current value: {item['value']} | Reference: {item['reference']} | Current input {direction}
              </div>
              <div style="height:0.55rem;background:#d3dde4;border-radius:999px;margin-top:0.55rem;overflow:hidden;">
                <div style="height:100%;width:{width:.1f}%;background:{color};border-radius:999px;"></div>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def build_report_text(case_id: str, result: dict, threshold: float) -> str:
    prob = float(result["prob"])
    label, _ = classify_risk(prob, threshold)
    clinical_values = result["clinical_values"]
    lines = [
        "NeuroClinFusion-5 Risk Report",
        f"Report label: {case_id or 'Not specified'}",
        f"Prediction target: {PREDICTION_ENDPOINT}",
        f"Prediction horizon: {PREDICTION_HORIZON}",
        f"Predicted progression risk: {prob:.4f}",
        f"Decision threshold: {threshold:.4f}",
        f"Risk category: {label}",
        "",
        "Clinical variables",
    ]
    for key in TOP5_COLUMNS:
        if key == "APOE4":
            lines.append(f"- APOE4 allele count: {float(clinical_values[key]):.0f}")
        else:
            lines.append(f"- {key}: {float(clinical_values[key]):.3f}")
    lines.extend(
        [
            "",
            "Clinical note: This output is intended as decision support and should be interpreted with clinical assessment.",
        ]
    )
    return "\n".join(lines)


def clinical_main() -> None:
    st.set_page_config(page_title="NeuroClinFusion-5", layout="wide", initial_sidebar_state="collapsed")
    inject_enterprise_css()

    model_ready = False
    threshold = None
    load_error = None
    try:
        _, threshold, _, _, _ = load_ensemble()
        model_ready = True
    except Exception as exc:
        load_error = exc

    if not model_ready:
        st.error(f"Prediction service unavailable: {load_error}")
        st.stop()

    render_header(model_ready=model_ready, threshold=threshold)

    defaults = {"FAQ": 2.0, "APOE4": 1.0, "RAVLT_immediate": 31.0, "CDRSB": 1.5, "LDELTOTAL": 5.0}
    with st.container(border=True):
        panel_title("Case Entry")
        intake_left, intake_right = st.columns([0.30, 0.70])
        with intake_right:
            uploaded = st.file_uploader("Preprocessed MRI volume (.nii or .nii.gz)", type=["nii", "gz"])
            mri_path = st.text_input("Local MRI path", value="")
        with intake_left:
            report_label = st.text_input(
                "Report label (optional)",
                value=st.session_state.get("case_id", ""),
                help="Used only for the downloadable report filename. It is not used by the prediction model.",
            )
            st.session_state["case_id"] = report_label
            mri_status = "Ready" if source_ready(uploaded, mri_path) else "Waiting"
            st.markdown(
                f"""
                <div class="report-box">
                <strong>Assessment summary</strong><br>
                Target: {PREDICTION_ENDPOINT}<br>
                Horizon: {PREDICTION_HORIZON}<br>
                MRI input: {mri_status}<br>
                Clinical profile: 5 variables
                </div>
                """,
                unsafe_allow_html=True,
            )

        panel_title("Clinical Variables")
        c1, c2, c3, c4, c5 = st.columns(5)
        clinical_values = {}
        with c1:
            clinical_values["FAQ"] = st.number_input(
                "FAQ",
                min_value=0.0,
                max_value=30.0,
                value=float(defaults["FAQ"]),
                step=1.0,
                format="%.0f",
                key="clinical_FAQ",
                help="Functional Activities Questionnaire, range 0-30.",
            )
        with c2:
            apoe4_count = st.selectbox(
                "APOE4 allele count",
                options=[0, 1, 2],
                index=int(float(defaults["APOE4"])),
                key="clinical_APOE4_count",
                help="Number of APOE epsilon 4 alleles: 0, 1, or 2.",
            )
            clinical_values["APOE4"] = float(apoe4_count)
        with c3:
            clinical_values["RAVLT_immediate"] = st.number_input(
                "RAVLT immediate",
                min_value=0.0,
                max_value=75.0,
                value=float(defaults["RAVLT_immediate"]),
                step=1.0,
                format="%.0f",
                key="clinical_RAVLT_immediate",
                help="RAVLT immediate recall total score, range 0-75.",
            )
        with c4:
            clinical_values["CDRSB"] = st.number_input(
                "CDR-SB",
                min_value=0.0,
                max_value=18.0,
                value=float(defaults["CDRSB"]),
                step=0.5,
                format="%.1f",
                key="clinical_CDRSB",
                help="Clinical Dementia Rating Sum of Boxes, range 0-18.",
            )
        with c5:
            clinical_values["LDELTOTAL"] = st.number_input(
                "Logical memory delayed",
                min_value=0.0,
                max_value=25.0,
                value=float(defaults["LDELTOTAL"]),
                step=1.0,
                format="%.0f",
                key="clinical_LDELTOTAL",
                help="Logical memory delayed recall score, range 0-25.",
            )

        infer_clicked = st.button("Run NeuroClinFusion-5 Assessment", type="primary", use_container_width=True)

    if infer_clicked:
        if not source_ready(uploaded, mri_path):
            st.warning("MRI file or local path is required.")
        else:
            try:
                st.session_state.pop("heatmap", None)
                st.session_state.pop("clinical_risk_signature", None)
                volume = read_source_volume(uploaded, mri_path)
                mri_tensor = preprocess_mri(volume)
                st.session_state["volume"] = volume
                st.session_state["mri_tensor"] = mri_tensor
            except Exception as exc:
                st.error(f"MRI loading failed: {exc}")
                st.stop()

    if infer_clicked and "mri_tensor" in st.session_state:
        try:
            prob, fold_probs, decision_threshold = predict(st.session_state["mri_tensor"], clinical_values)
            st.session_state["result"] = {
                "prob": prob,
                "fold_probs": fold_probs,
                "threshold": decision_threshold,
                "clinical_values": clinical_values,
            }
            with st.spinner("Generating clinical-conditioned MRI heatmap..."):
                try:
                    heatmap, heatmap_models = generate_clinical_conditioned_heatmap(
                        st.session_state["mri_tensor"], clinical_values
                    )
                    st.session_state["heatmap"] = heatmap
                    st.session_state["heatmap_models"] = heatmap_models
                    with st.spinner("Computing clinical risk signature..."):
                        try:
                            st.session_state["clinical_risk_signature"] = generate_clinical_risk_signature(
                                st.session_state["mri_tensor"],
                                clinical_values,
                                prob,
                            )
                        except Exception as exc:
                            st.session_state.pop("clinical_risk_signature", None)
                            st.warning(f"Clinical risk signature could not be generated: {exc}")
                except Exception as exc:
                    st.session_state.pop("heatmap", None)
                    st.warning(f"Risk prediction completed, but heatmap generation failed: {exc}")
        except Exception as exc:
            st.error(f"Prediction failed: {exc}")
            st.stop()

    volume = st.session_state.get("volume")
    if volume is not None:
        with st.container(border=True):
            panel_title("MRI Review")
            heatmap = st.session_state.get("heatmap")
            if heatmap is not None:
                render_heatmap_review(volume, heatmap, st.session_state.get("result"))
                signature_items = st.session_state.get("clinical_risk_signature")
                if signature_items:
                    render_clinical_risk_signature(signature_items)
            else:
                render_compact_mri_review(volume)

    result = st.session_state.get("result")
    if result is not None:
        prob = float(result["prob"])
        decision_threshold = float(result["threshold"])
        label, risk_class = classify_risk(prob, decision_threshold)
        margin = prob - decision_threshold

        with st.container(border=True):
            panel_title("Risk Assessment")
            p1, p2, p3 = st.columns(3)
            p1.metric("3-year AD progression risk", f"{prob:.4f}")
            p2.metric("Decision threshold", f"{decision_threshold:.4f}")
            p3.metric("Decision margin", f"{margin:+.4f}")
            st.markdown(f'<div class="{risk_class}">Assessment result: {label}</div>', unsafe_allow_html=True)
            st.progress(min(max(prob, 0.0), 1.0))
            report_text = build_report_text(st.session_state.get("case_id", ""), result, decision_threshold)
            st.download_button(
                "Download report",
                data=report_text,
                file_name=f"{st.session_state.get('case_id', 'case') or 'case'}_NeuroClinFusion5_report.txt",
                mime="text/plain",
                use_container_width=True,
            )


if __name__ == "__main__":
    clinical_main()
