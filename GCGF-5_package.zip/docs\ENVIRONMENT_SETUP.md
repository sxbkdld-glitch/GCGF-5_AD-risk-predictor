# Environment Configuration

This deployment was prepared for Python-based Streamlit inference.

## Option 1: Conda

Create the environment:

```bash
conda env create -f environment.yml
conda activate gcgf5-deploy
```

Run:

```bash
python -m streamlit run app.py --server.port 8501
```

## Option 2: Python venv

Create a local environment:

```bash
python -m venv .venv
```

Activate it on Windows:

```bash
.venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run:

```bash
python -m streamlit run app.py --server.port 8501
```

Or double-click:

```text
run_streamlit.bat
```

## Required Packages

Main packages:

```text
streamlit
torch
numpy
pandas
nibabel
plotly
scikit-learn
tqdm
```

## CUDA Notes

The app can run on CPU or CUDA. If CUDA is available, PyTorch will use GPU automatically.

For GPU inference, install a PyTorch build compatible with your local CUDA version from the official PyTorch installation page.

## Model Weight Placement

Before running inference, extract the checkpoint archive into the project root:

```text
GCGF-5_checkpoints.zip
```

Expected structure:

```text
checkpoints/top5/top5_fold0/best_full_clinical_guided_densenet121.pt
checkpoints/top5/top5_fold1/best_full_clinical_guided_densenet121.pt
checkpoints/top5/top5_fold2/best_full_clinical_guided_densenet121.pt
checkpoints/top5/top5_fold3/best_full_clinical_guided_densenet121.pt
checkpoints/top5/top5_fold4/best_full_clinical_guided_densenet121.pt
```

## Optional Path Override

If weights are stored elsewhere, set:

```powershell
$env:GCGF_MODEL_ROOT = "D:\path\to\Top-5 clinical variables"
python -m streamlit run app.py
```

