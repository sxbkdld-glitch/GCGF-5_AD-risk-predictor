# Clinical Variables: Original ADNI Measurement and Scoring

GCGF-5 uses five baseline clinical variables together with preprocessed T1 MRI:

```text
FAQ
APOE4
RAVLT_immediate
CDRSB
LDELTOTAL
```

This document describes how these variables are originally measured in ADNI clinical/neuropsychological assessments and what value should be entered into the deployment app.

Use the raw baseline ADNI values. Do not manually normalize, z-score, or rescale them. The app applies the clinical normalizer saved in each model checkpoint.

Official ADNI references:

- ADNI Study Documents: https://adni.loni.usc.edu/methods/documents/
- ADNI3 Clinical Protocol: https://adni.loni.usc.edu/wp-content/themes/freshnews-dev-v2/documents/clinical/ADNI3_Protocol.pdf
- ADNI Genetics Sample Collection: https://adni.loni.usc.edu/wp-content/themes/freshnews-dev-v2/documents/genetics/Genetics_Sample_Collection_Processing_and_Shipment.pdf

## 1. FAQ

Model input field:

```text
FAQ
```

Original ADNI assessment:

```text
Activities of Daily Living / Functional Assessment Questionnaire
```

Original measurement method:

According to the ADNI3 clinical protocol, FAQ is based on an interview with a caregiver or qualified study partner. The participant is rated on his/her ability to carry out ten complex activities of daily living.

Original scoring used for deployment:

```text
FAQ = total Functional Assessment Questionnaire score
```

The standard FAQ total is obtained by summing the item ratings across the ten daily-function activities.

Typical score direction:

```text
Higher FAQ = worse instrumental daily functioning.
Lower FAQ = better instrumental daily functioning.
```

Value to enter in the app:

```text
Enter the raw ADNI FAQ total score.
```

## 2. APOE4

Model input field:

```text
APOE4
```

Original ADNI assessment:

```text
APOE genotyping from biological sample collection
```

Original measurement method:

ADNI includes genotyping sample collection. The ADNI genetics sample documentation notes that collected blood/DNA is used for APOE genotyping and genome-wide genotyping.

Original coding used for deployment:

```text
APOE4 = number of APOE epsilon 4 alleles
```

Coding:

```text
0 = no APOE epsilon 4 allele
1 = one APOE epsilon 4 allele
2 = two APOE epsilon 4 alleles
```

Typical score direction:

```text
Higher APOE4 count = greater APOE epsilon 4 genetic risk burden.
```

Value to enter in the app:

```text
Enter 0, 1, or 2.
```

Important:

The deployed GCGF-5 checkpoint was trained with the ADNI `APOE4` allele-count field. Do not convert APOE4 to a binary carrier/non-carrier value unless the checkpoint has been retrained with binary coding.

## 3. RAVLT_immediate

Model input field:

```text
RAVLT_immediate
```

Original ADNI assessment:

```text
Rey Auditory Verbal Learning Test / Auditory Verbal Learning Test
```

Original measurement method:

The ADNI3 clinical protocol describes the Auditory Verbal Learning Test as a list-learning task assessing multiple cognitive parameters associated with learning and memory.

Original scoring used for deployment:

```text
RAVLT_immediate = total immediate recall score across the immediate learning trials
```

In the ADNI-derived clinical table used for this model, `RAVLT_immediate` is the raw total immediate recall score. For the standard 15-word, five-trial learning format, this corresponds to the sum of correctly recalled words across the immediate learning trials.

Typical score direction:

```text
Higher RAVLT_immediate = better immediate verbal learning and memory.
Lower RAVLT_immediate = worse immediate verbal learning and memory.
```

Value to enter in the app:

```text
Enter the raw ADNI RAVLT_immediate value.
```

## 4. CDRSB

Model input field:

```text
CDRSB
```

Original ADNI assessment:

```text
Clinical Dementia Rating Scale
```

Original measurement method:

The ADNI3 clinical protocol describes CDR as an assessment of impairment across six categories:

```text
Memory
Orientation
Judgment and problem solving
Community affairs
Home and hobbies
Personal care
```

Original scoring used for deployment:

```text
CDRSB = Clinical Dementia Rating Sum of Boxes
```

It is obtained by summing the six CDR box scores.

Typical score direction:

```text
Higher CDRSB = greater cognitive/functional impairment.
Lower CDRSB = less cognitive/functional impairment.
```

Value to enter in the app:

```text
Enter the raw ADNI CDRSB value.
```

## 5. LDELTOTAL

Model input field:

```text
LDELTOTAL
```

Original ADNI assessment:

```text
Logical Memory II delayed paragraph recall
```

Original measurement method:

The ADNI3 clinical protocol states that Logical Memory I and II use a modified episodic memory measure from the Wechsler Memory Scale-Revised. In this assessment, free recall of one short story is elicited immediately after it is read aloud and again after an approximately 30-minute delay.

Original scoring used for deployment:

```text
LDELTOTAL = total Logical Memory delayed recall score
```

In ADNI eligibility descriptions, the Logical Memory II delayed paragraph recall uses Paragraph A only and has a maximum score of 25.

Typical score direction:

```text
Higher LDELTOTAL = better delayed episodic memory.
Lower LDELTOTAL = worse delayed episodic memory.
```

Value to enter in the app:

```text
Enter the raw ADNI LDELTOTAL value.
```

## Input Consistency Checklist

Before running inference:

1. Use baseline clinical values corresponding to the same visit as the baseline MRI.
2. Enter raw ADNI values, not normalized values.
3. Enter `APOE4` as allele count: 0, 1, or 2.
4. Enter `FAQ`, `RAVLT_immediate`, `CDRSB`, and `LDELTOTAL` as raw ADNI assessment-derived scores.
5. Do not guess missing values for real clinical use. If imputation is used in a research demonstration, document the imputation method.

