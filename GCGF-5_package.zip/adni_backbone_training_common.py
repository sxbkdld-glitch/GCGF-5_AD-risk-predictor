#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared training code for ADNI MRI-only and clinical-guided backbone comparisons."""

from __future__ import annotations

import argparse
import inspect
import json
import math
import os
import random
import re
import time
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, roc_auc_score, roc_curve
from sklearn.model_selection import StratifiedKFold, train_test_split
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

try:
    import nibabel as nib
except Exception:
    nib = None


CLINICAL_COLUMNS = [
    "AGE",
    "Gender",
    "APOE4",
    "PTEDUCAT",
    "MMSE",
    "ADAS11",
    "CDRSB",
    "ADAS13",
    "RAVLT_immediate",
    "RAVLT_learning",
    "RAVLT_forgetting",
    "RAVLT_perc_forgetting",
    "LDELTOTAL",
    "FAQ",
]

GROUPS = {
    "demo": ["AGE", "Gender", "APOE4", "PTEDUCAT"],
    "global": ["MMSE", "ADAS11", "ADAS13", "CDRSB"],
    "memory": [
        "RAVLT_immediate",
        "RAVLT_learning",
        "RAVLT_forgetting",
        "RAVLT_perc_forgetting",
        "LDELTOTAL",
    ],
    "func": ["FAQ"],
}

BACKBONE_CHOICES = ["resnet18", "densenet121", "convnext_tiny", "swinunetr"]


# -------------------------
# General utilities
# -------------------------


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True
    if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
        torch.backends.cuda.matmul.allow_tf32 = True
    if hasattr(torch.backends.cudnn, "allow_tf32"):
        torch.backends.cudnn.allow_tf32 = True


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def save_json(obj: object, path: Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def subject_id_from_filename(path: Path) -> Optional[str]:
    m = re.search(r"(\d{3}_S_\d{4})", path.name)
    return m.group(1) if m else None


def normalize_split_value(x: object) -> str:
    s = str(x).strip().lower()
    if s in {"train", "tr", "training"}:
        return "train"
    if s in {"val", "valid", "validation", "dev"}:
        return "val"
    if s in {"test", "te", "testing"}:
        return "test"
    return s


def infer_outcome_numeric(series: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(series):
        return series.astype(int)

    mapping = {
        "pmci": 1,
        "p-mci": 1,
        "progressive": 1,
        "progressor": 1,
        "converter": 1,
        "converted": 1,
        "1": 1,
        "smci": 0,
        "s-mci": 0,
        "stable": 0,
        "nonconverter": 0,
        "non-converter": 0,
        "0": 0,
    }

    def convert(v: object) -> int:
        key = str(v).strip().lower()
        if key not in mapping:
            raise ValueError(f"Unsupported outcome value: {v!r}. Use 0/1 or pMCI/sMCI.")
        return mapping[key]

    return series.map(convert).astype(int)


def read_clinical_csv(path: Path) -> pd.DataFrame:
    encodings = ["utf-8-sig", "utf-8", "gbk", "gb18030"]
    last_error = None
    for enc in encodings:
        try:
            return pd.read_csv(path, encoding=enc)
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f"Failed to read CSV {path}. Last error: {last_error}")


def encode_common_categorical_clinical_columns(clinical: pd.DataFrame) -> pd.DataFrame:
    clinical = clinical.copy()
    if "Gender" in clinical.columns:
        gender_map = {
            "m": 1,
            "male": 1,
            "man": 1,
            "1": 1,
            "f": 0,
            "female": 0,
            "woman": 0,
            "0": 0,
        }

        def map_gender(v: object) -> object:
            if pd.isna(v):
                return np.nan
            key = str(v).strip().lower()
            return gender_map.get(key, v)

        clinical["Gender"] = clinical["Gender"].map(map_gender)
    return clinical


# -------------------------
# Data
# -------------------------


def build_manifest(
    mri_dir: Path,
    clinical_csv: Path,
    out_dir: Path,
    max_samples: Optional[int] = None,
) -> pd.DataFrame:
    clinical = read_clinical_csv(clinical_csv)
    clinical = encode_common_categorical_clinical_columns(clinical)

    required = ["Subject_ID", "outcome"] + CLINICAL_COLUMNS
    missing = [c for c in required if c not in clinical.columns]
    if missing:
        raise ValueError(f"Clinical CSV is missing required columns: {missing}")

    clinical = clinical.copy()
    clinical["Subject_ID"] = clinical["Subject_ID"].astype(str).str.strip()
    clinical["label"] = infer_outcome_numeric(clinical["outcome"])

    mri_files = sorted(mri_dir.rglob("*.nii.gz"))
    if not mri_files:
        raise FileNotFoundError(f"No .nii.gz files found under {mri_dir}")

    rows = []
    unmatched = []
    clinical_by_sid = clinical.set_index("Subject_ID", drop=False)
    for fp in mri_files:
        sid = subject_id_from_filename(fp)
        if sid is None:
            unmatched.append((str(fp), "cannot_parse_subject_id"))
            continue
        if sid not in clinical_by_sid.index:
            unmatched.append((str(fp), "subject_id_not_in_clinical_csv"))
            continue

        rec = clinical_by_sid.loc[sid]
        if isinstance(rec, pd.DataFrame):
            rec = rec.iloc[0]

        row = {"Subject_ID": sid, "mri_path": str(fp), "label": int(rec["label"])}
        if "split" in clinical.columns:
            row["split"] = normalize_split_value(rec["split"])
        for c in CLINICAL_COLUMNS:
            row[c] = rec[c]
        rows.append(row)

    manifest = pd.DataFrame(rows)
    if manifest.empty:
        raise RuntimeError("No matched MRI-clinical samples. Check Subject_ID values and MRI filenames.")

    manifest = manifest.sort_values(["Subject_ID", "mri_path"]).reset_index(drop=True)

    if max_samples is not None and max_samples > 0 and len(manifest) > max_samples:
        original_manifest = manifest.copy()
        per_class = max(1, max_samples // int(original_manifest["label"].nunique()))
        sampled_parts = []
        for _, group in original_manifest.groupby("label"):
            sampled_parts.append(group.sample(n=min(len(group), per_class), random_state=123))
        manifest = pd.concat(sampled_parts, axis=0)
        if len(manifest) < max_samples:
            remain = max_samples - len(manifest)
            remaining_pool = original_manifest.drop(index=manifest.index, errors="ignore")
            if len(remaining_pool) > 0:
                extra = remaining_pool.sample(n=min(remain, len(remaining_pool)), random_state=123)
                manifest = pd.concat([manifest, extra], axis=0)
        manifest = manifest.sample(frac=1.0, random_state=123).reset_index(drop=True)

    ensure_dir(out_dir)
    manifest.to_csv(out_dir / "manifest_mri_clinical_matched_all.csv", index=False, encoding="utf-8-sig")
    if unmatched:
        pd.DataFrame(unmatched, columns=["mri_path", "reason"]).to_csv(
            out_dir / "manifest_unmatched_mri.csv", index=False, encoding="utf-8-sig"
        )

    print(f"[DATA] MRI files found: {len(mri_files)}")
    print(f"[DATA] Matched usable samples: {len(manifest)}")
    print(f"[DATA] Label counts: {manifest['label'].value_counts().to_dict()}")
    return manifest


def split_manifest(
    manifest: pd.DataFrame,
    out_dir: Path,
    fold: int,
    n_splits: int,
    seed: int,
    use_csv_split: bool = True,
    val_size: float = 0.2,
) -> Tuple[pd.DataFrame, pd.DataFrame, Optional[pd.DataFrame]]:
    if use_csv_split and "split" in manifest.columns:
        tmp = manifest.copy()
        tmp["split"] = tmp["split"].map(normalize_split_value)
        split_values = set(tmp["split"].dropna().unique())

        if {"train", "val"}.issubset(split_values):
            train_df = tmp[tmp["split"] == "train"].reset_index(drop=True)
            val_df = tmp[tmp["split"] == "val"].reset_index(drop=True)
            test_df = tmp[tmp["split"] == "test"].reset_index(drop=True) if "test" in split_values else None
            print("[SPLIT] Using train/val/test split from clinical CSV.")
        elif {"train", "test"}.issubset(split_values):
            train_pool = tmp[tmp["split"] == "train"].reset_index(drop=True)
            test_df = tmp[tmp["split"] == "test"].reset_index(drop=True)
            y_pool = train_pool["label"].astype(int).values
            if len(np.unique(y_pool)) < 2 or pd.Series(y_pool).value_counts().min() < 2:
                raise ValueError("Cannot create stratified validation split from CSV train split.")
            tr_idx, va_idx = train_test_split(
                np.arange(len(train_pool)),
                test_size=val_size,
                random_state=seed,
                stratify=y_pool,
            )
            train_df = train_pool.iloc[tr_idx].reset_index(drop=True)
            val_df = train_pool.iloc[va_idx].reset_index(drop=True)
            print("[SPLIT] CSV has train/test only. Holding out CSV test and creating validation from train.")
        else:
            train_df = val_df = test_df = None
    else:
        train_df = val_df = test_df = None

    if train_df is None or val_df is None or train_df.empty or val_df.empty:
        y = manifest["label"].values
        min_class = int(pd.Series(y).value_counts().min())
        if n_splits > min_class:
            raise ValueError(f"n_splits={n_splits} is too large for the smallest class count={min_class}.")
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        splits = list(skf.split(np.zeros(len(manifest)), y))
        if fold < 0 or fold >= len(splits):
            raise ValueError(f"fold must be in [0, {n_splits - 1}], got {fold}")
        train_idx, val_idx = splits[fold]
        train_df = manifest.iloc[train_idx].reset_index(drop=True)
        val_df = manifest.iloc[val_idx].reset_index(drop=True)
        test_df = None
        print(f"[SPLIT] Using StratifiedKFold: fold {fold}/{n_splits}")

    train_df.to_csv(out_dir / f"manifest_train_fold{fold}_of_{n_splits}.csv", index=False, encoding="utf-8-sig")
    val_df.to_csv(out_dir / f"manifest_val_fold{fold}_of_{n_splits}.csv", index=False, encoding="utf-8-sig")
    if test_df is not None and len(test_df) > 0:
        test_df.to_csv(out_dir / "manifest_test_from_csv_split.csv", index=False, encoding="utf-8-sig")

    print(f"[SPLIT] Train samples: {len(train_df)}, labels: {train_df['label'].value_counts().to_dict()}")
    print(f"[SPLIT] Val samples:   {len(val_df)}, labels: {val_df['label'].value_counts().to_dict()}")
    if test_df is not None and len(test_df) > 0:
        print(f"[SPLIT] Test samples:  {len(test_df)}, labels: {test_df['label'].value_counts().to_dict()}")
    return train_df, val_df, test_df


def fit_clinical_normalizer(train_df: pd.DataFrame) -> Dict[str, Dict[str, float]]:
    stats = {}
    for c in CLINICAL_COLUMNS:
        values = pd.to_numeric(train_df[c], errors="coerce")
        median = float(values.median())
        filled = values.fillna(median)
        mean = float(filled.mean())
        std = float(filled.std(ddof=0))
        if not np.isfinite(std) or std < 1e-6:
            std = 1.0
        stats[c] = {"median": median, "mean": mean, "std": std}
    return stats


def apply_clinical_normalizer(df: pd.DataFrame, stats: Dict[str, Dict[str, float]]) -> pd.DataFrame:
    out = df.copy()
    for c in CLINICAL_COLUMNS:
        values = pd.to_numeric(out[c], errors="coerce").fillna(stats[c]["median"])
        out[c] = (values - stats[c]["mean"]) / stats[c]["std"]
    return out


def validate_selected_clinical_columns(columns: Optional[Sequence[str]]) -> List[str]:
    if not columns:
        return []
    cleaned = [str(c).strip() for c in columns if str(c).strip()]
    invalid = [c for c in cleaned if c not in CLINICAL_COLUMNS]
    if invalid:
        raise ValueError(f"Unknown selected clinical columns: {invalid}. Allowed columns are: {CLINICAL_COLUMNS}")
    seen = set()
    unique = []
    for col in cleaned:
        if col not in seen:
            unique.append(col)
            seen.add(col)
    return unique


def mask_unselected_clinical_columns(df: pd.DataFrame, selected_columns: Sequence[str]) -> pd.DataFrame:
    selected = validate_selected_clinical_columns(selected_columns)
    if not selected:
        return df
    out = df.copy()
    keep = set(selected)
    for col in CLINICAL_COLUMNS:
        if col not in keep:
            out[col] = 0.0
    return out


class MRICLClinicalDataset(Dataset):
    def __init__(self, df: pd.DataFrame, target_shape: Tuple[int, int, int], augment: bool = False) -> None:
        self.df = df.reset_index(drop=True)
        self.target_shape = tuple(target_shape)
        self.augment = augment

    def __len__(self) -> int:
        return len(self.df)

    def _load_mri(self, path: str) -> torch.Tensor:
        if nib is None:
            raise ImportError("nibabel is required to read .nii.gz MRI files. Install it in the training environment.")
        img = nib.load(path)
        arr = np.asarray(img.get_fdata(dtype=np.float32))
        arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)

        nonzero = arr[np.abs(arr) > 1e-6]
        if nonzero.size > 50:
            lo, hi = np.percentile(nonzero, [0.5, 99.5])
            arr = np.clip(arr, lo, hi)
            clipped_nonzero = arr[np.abs(arr) > 1e-6]
            mean = float(clipped_nonzero.mean())
            std = float(clipped_nonzero.std())
        else:
            mean = float(arr.mean())
            std = float(arr.std())

        if not np.isfinite(std) or std < 1e-6:
            std = 1.0
        arr = (arr - mean) / std

        x = torch.from_numpy(arr).unsqueeze(0).unsqueeze(0)
        if tuple(arr.shape) != self.target_shape:
            x = F.interpolate(x, size=self.target_shape, mode="trilinear", align_corners=False)
        x = x.squeeze(0)

        if self.augment:
            if random.random() < 0.5:
                x = torch.flip(x, dims=[1])
            if random.random() < 0.5:
                x = x + 0.01 * torch.randn_like(x)
        return x.float()

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.df.iloc[idx]
        mri = self._load_mri(row["mri_path"])
        clinical = torch.tensor(row[CLINICAL_COLUMNS].astype(float).values, dtype=torch.float32)
        label = torch.tensor(float(row["label"]), dtype=torch.float32)
        return {
            "mri": mri,
            "clinical": clinical,
            "label": label,
            "subject_id": row["Subject_ID"],
            "mri_path": row["mri_path"],
        }


# -------------------------
# Backbone blocks
# -------------------------


class ConvBNAct3D(nn.Sequential):
    def __init__(
        self,
        in_ch: int,
        out_ch: int,
        kernel_size: int = 3,
        stride: int = 1,
        groups: int = 1,
        activation: bool = True,
    ) -> None:
        padding = kernel_size // 2
        layers: List[nn.Module] = [
            nn.Conv3d(in_ch, out_ch, kernel_size, stride, padding, groups=groups, bias=False),
            nn.BatchNorm3d(out_ch),
        ]
        if activation:
            layers.append(nn.ReLU(inplace=True))
        super().__init__(*layers)


class BasicBlock3D(nn.Module):
    expansion = 1

    def __init__(self, inplanes: int, planes: int, stride: int = 1) -> None:
        super().__init__()
        self.conv1 = nn.Conv3d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv3d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(planes)
        self.downsample = None
        if stride != 1 or inplanes != planes * self.expansion:
            self.downsample = nn.Sequential(
                nn.Conv3d(inplanes, planes * self.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm3d(planes * self.expansion),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        out = self.relu(out + identity)
        return out


class ResNetBackbone3D(nn.Module):
    def __init__(self, layers: Sequence[int], in_channels: int = 1, base_channels: int = 64) -> None:
        super().__init__()
        self.inplanes = base_channels
        self.conv1 = nn.Conv3d(in_channels, base_channels, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm3d(base_channels)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(base_channels, layers[0], stride=1)
        self.layer2 = self._make_layer(base_channels * 2, layers[1], stride=2)
        self.layer3 = self._make_layer(base_channels * 4, layers[2], stride=2)
        self.layer4 = self._make_layer(base_channels * 8, layers[3], stride=2)
        self.stage3_channels = base_channels * 4
        self.out_channels = base_channels * 8

    def _make_layer(self, planes: int, blocks: int, stride: int) -> nn.Sequential:
        layers = [BasicBlock3D(self.inplanes, planes, stride=stride)]
        self.inplanes = planes * BasicBlock3D.expansion
        for _ in range(1, blocks):
            layers.append(BasicBlock3D(self.inplanes, planes, stride=1))
        return nn.Sequential(*layers)

    def forward_to_stage3(self, x: torch.Tensor) -> torch.Tensor:
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.maxpool(x)
        x = self.layer1(x)
        x = self.layer2(x)
        return self.layer3(x)

    def forward_stage4(self, f3: torch.Tensor) -> torch.Tensor:
        return self.layer4(f3)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        f3 = self.forward_to_stage3(x)
        f4 = self.forward_stage4(f3)
        return f3, f4

    def freeze_early_layers(self) -> None:
        for module in [self.conv1, self.bn1, self.layer1]:
            for p in module.parameters():
                p.requires_grad = False


class DenseLayer3D(nn.Module):
    def __init__(self, num_input_features: int, growth_rate: int, bn_size: int, drop_rate: float) -> None:
        super().__init__()
        inter_features = bn_size * growth_rate
        self.norm1 = nn.BatchNorm3d(num_input_features)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv3d(num_input_features, inter_features, kernel_size=1, stride=1, bias=False)
        self.norm2 = nn.BatchNorm3d(inter_features)
        self.relu2 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv3d(inter_features, growth_rate, kernel_size=3, stride=1, padding=1, bias=False)
        self.drop_rate = float(drop_rate)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        new_features = self.conv1(self.relu1(self.norm1(x)))
        new_features = self.conv2(self.relu2(self.norm2(new_features)))
        if self.drop_rate > 0:
            new_features = F.dropout(new_features, p=self.drop_rate, training=self.training)
        return new_features


class DenseBlock3D(nn.Module):
    def __init__(self, num_layers: int, num_input_features: int, growth_rate: int, bn_size: int, drop_rate: float) -> None:
        super().__init__()
        self.layers = nn.ModuleList(
            [
                DenseLayer3D(num_input_features + i * growth_rate, growth_rate, bn_size, drop_rate)
                for i in range(num_layers)
            ]
        )

    def forward(self, init_features: torch.Tensor) -> torch.Tensor:
        features = init_features
        for layer in self.layers:
            new_features = layer(features)
            features = torch.cat([features, new_features], dim=1)
        return features


class Transition3D(nn.Sequential):
    def __init__(self, num_input_features: int, num_output_features: int) -> None:
        super().__init__(
            nn.BatchNorm3d(num_input_features),
            nn.ReLU(inplace=True),
            nn.Conv3d(num_input_features, num_output_features, kernel_size=1, stride=1, bias=False),
            nn.AvgPool3d(kernel_size=2, stride=2),
        )


class DenseNetBackbone3D(nn.Module):
    def __init__(
        self,
        block_config: Sequence[int],
        in_channels: int = 1,
        growth_rate: int = 32,
        init_features: int = 64,
        bn_size: int = 4,
        drop_rate: float = 0.0,
        compression: float = 0.5,
    ) -> None:
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv3d(in_channels, init_features, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm3d(init_features),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(kernel_size=3, stride=2, padding=1),
        )

        num_features = init_features
        self.block1 = DenseBlock3D(block_config[0], num_features, growth_rate, bn_size, drop_rate)
        num_features += block_config[0] * growth_rate
        self.trans1 = Transition3D(num_features, int(num_features * compression))
        num_features = int(num_features * compression)

        self.block2 = DenseBlock3D(block_config[1], num_features, growth_rate, bn_size, drop_rate)
        num_features += block_config[1] * growth_rate
        self.trans2 = Transition3D(num_features, int(num_features * compression))
        num_features = int(num_features * compression)

        self.block3 = DenseBlock3D(block_config[2], num_features, growth_rate, bn_size, drop_rate)
        num_features += block_config[2] * growth_rate
        self.stage3_channels = num_features
        self.trans3 = Transition3D(num_features, int(num_features * compression))
        num_features = int(num_features * compression)

        self.block4 = DenseBlock3D(block_config[3], num_features, growth_rate, bn_size, drop_rate)
        num_features += block_config[3] * growth_rate
        self.norm5 = nn.BatchNorm3d(num_features)
        self.out_channels = num_features

    def forward_to_stage3(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.trans1(self.block1(x))
        x = self.trans2(self.block2(x))
        return self.block3(x)

    def forward_stage4(self, f3: torch.Tensor) -> torch.Tensor:
        x = self.trans3(f3)
        x = self.block4(x)
        return F.relu(self.norm5(x), inplace=True)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        f3 = self.forward_to_stage3(x)
        f4 = self.forward_stage4(f3)
        return f3, f4

    def freeze_early_layers(self) -> None:
        for module in [self.stem, self.block1, self.trans1]:
            for p in module.parameters():
                p.requires_grad = False


class LayerNorm3D(nn.Module):
    def __init__(self, normalized_shape: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.normalized_shape = (normalized_shape,)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.permute(0, 2, 3, 4, 1)
        x = F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        return x.permute(0, 4, 1, 2, 3).contiguous()


class DropPath(nn.Module):
    def __init__(self, drop_prob: float = 0.0) -> None:
        super().__init__()
        self.drop_prob = float(drop_prob)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.drop_prob == 0.0 or not self.training:
            return x
        keep_prob = 1.0 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
        random_tensor.floor_()
        return x.div(keep_prob) * random_tensor


class ConvNeXtBlock3D(nn.Module):
    def __init__(self, dim: int, drop_path: float = 0.0, layer_scale_init_value: float = 1e-6) -> None:
        super().__init__()
        self.dwconv = nn.Conv3d(dim, dim, kernel_size=7, padding=3, groups=dim)
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.pwconv1 = nn.Linear(dim, 4 * dim)
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(4 * dim, dim)
        self.gamma = (
            nn.Parameter(layer_scale_init_value * torch.ones(dim), requires_grad=True)
            if layer_scale_init_value > 0
            else None
        )
        self.drop_path = DropPath(drop_path)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        shortcut = x
        x = self.dwconv(x)
        x = x.permute(0, 2, 3, 4, 1)
        x = self.norm(x)
        x = self.pwconv2(self.act(self.pwconv1(x)))
        if self.gamma is not None:
            x = self.gamma * x
        x = x.permute(0, 4, 1, 2, 3).contiguous()
        return shortcut + self.drop_path(x)


class ConvNeXtBackbone3D(nn.Module):
    def __init__(
        self,
        in_channels: int = 1,
        depths: Sequence[int] = (3, 3, 9, 3),
        dims: Sequence[int] = (48, 96, 192, 384),
        drop_path_rate: float = 0.1,
        use_checkpoint: bool = False,
    ) -> None:
        super().__init__()
        self.use_checkpoint = use_checkpoint
        self.downsample_layers = nn.ModuleList()
        self.downsample_layers.append(
            nn.Sequential(nn.Conv3d(in_channels, dims[0], kernel_size=4, stride=4), LayerNorm3D(dims[0]))
        )
        for i in range(3):
            self.downsample_layers.append(
                nn.Sequential(LayerNorm3D(dims[i]), nn.Conv3d(dims[i], dims[i + 1], kernel_size=2, stride=2))
            )

        dp_rates = torch.linspace(0, drop_path_rate, sum(depths)).tolist()
        cursor = 0
        self.stages = nn.ModuleList()
        for i in range(4):
            blocks = [ConvNeXtBlock3D(dims[i], drop_path=dp_rates[cursor + j]) for j in range(depths[i])]
            self.stages.append(nn.Sequential(*blocks))
            cursor += depths[i]

        self.final_norm = LayerNorm3D(dims[-1])
        self.stage3_channels = dims[2]
        self.out_channels = dims[3]

    def _run_stage(self, stage: nn.Sequential, x: torch.Tensor) -> torch.Tensor:
        if self.use_checkpoint and self.training:
            from torch.utils.checkpoint import checkpoint

            for block in stage:
                x = checkpoint(block, x, use_reentrant=False)
            return x
        return stage(x)

    def forward_to_stage3(self, x: torch.Tensor) -> torch.Tensor:
        x = self.downsample_layers[0](x)
        x = self._run_stage(self.stages[0], x)
        x = self.downsample_layers[1](x)
        x = self._run_stage(self.stages[1], x)
        x = self.downsample_layers[2](x)
        return self._run_stage(self.stages[2], x)

    def forward_stage4(self, f3: torch.Tensor) -> torch.Tensor:
        x = self.downsample_layers[3](f3)
        x = self._run_stage(self.stages[3], x)
        return self.final_norm(x)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        f3 = self.forward_to_stage3(x)
        f4 = self.forward_stage4(f3)
        return f3, f4

    def freeze_early_layers(self) -> None:
        for module in [self.downsample_layers[0], self.stages[0], self.downsample_layers[1], self.stages[1]]:
            for p in module.parameters():
                p.requires_grad = False


class SwinUNETREncoderBackbone3D(nn.Module):
    """MONAI SwinUNETR SwinTransformer encoder exposed as stage3/stage4 features."""

    def __init__(
        self,
        in_channels: int = 1,
        embed_dim: int = 24,
        patch_size: Sequence[int] = (4, 4, 4),
        window_size: Sequence[int] = (7, 7, 7),
        depths: Sequence[int] = (2, 2, 2, 2),
        num_heads: Sequence[int] = (3, 6, 12, 24),
        use_checkpoint: bool = True,
        drop_rate: float = 0.0,
        attn_drop_rate: float = 0.0,
        drop_path_rate: float = 0.1,
    ) -> None:
        super().__init__()
        try:
            from monai.networks.nets.swin_unetr import SwinTransformer
        except Exception as exc:
            raise ImportError(
                "SwinUNETR encoder requires MONAI. Install it in the training environment, "
                "for example: pip install monai"
            ) from exc

        kwargs = {
            "in_chans": in_channels,
            "embed_dim": embed_dim,
            "window_size": tuple(window_size),
            "patch_size": tuple(patch_size),
            "depths": tuple(depths),
            "num_heads": tuple(num_heads),
            "mlp_ratio": 4.0,
            "qkv_bias": True,
            "drop_rate": drop_rate,
            "attn_drop_rate": attn_drop_rate,
            "drop_path_rate": drop_path_rate,
            "norm_layer": nn.LayerNorm,
            "use_checkpoint": use_checkpoint,
            "spatial_dims": 3,
            "downsample": "merging",
        }
        signature = inspect.signature(SwinTransformer)
        kwargs = {k: v for k, v in kwargs.items() if k in signature.parameters}
        self.swin = SwinTransformer(**kwargs)
        self.stage3_channels = embed_dim * 8
        self.out_channels = embed_dim * 16
        self.out_norm = LayerNorm3D(self.out_channels)

    def _patch_and_layers_to_stage3(self, x: torch.Tensor) -> torch.Tensor:
        x0 = self.swin.patch_embed(x)
        x0 = self.swin.pos_drop(x0)
        x1 = self.swin.layers1[0](x0.contiguous())
        x2 = self.swin.layers2[0](x1.contiguous())
        return self.swin.layers3[0](x2.contiguous())

    def forward_to_stage3(self, x: torch.Tensor) -> torch.Tensor:
        return self._patch_and_layers_to_stage3(x)

    def forward_stage4(self, f3: torch.Tensor) -> torch.Tensor:
        x4 = self.swin.layers4[0](f3.contiguous())
        return self.out_norm(x4)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        f3 = self.forward_to_stage3(x)
        f4 = self.forward_stage4(f3)
        return f3, f4

    def freeze_early_layers(self) -> None:
        for module_name in ["patch_embed", "layers1", "layers2"]:
            module = getattr(self.swin, module_name, None)
            if module is not None:
                for p in module.parameters():
                    p.requires_grad = False


def build_backbone(backbone_name: str, args: argparse.Namespace) -> nn.Module:
    if backbone_name == "resnet18":
        return ResNetBackbone3D(layers=(2, 2, 2, 2), in_channels=1, base_channels=args.resnet_base_channels)
    if backbone_name == "densenet121":
        return DenseNetBackbone3D(
            block_config=(6, 12, 24, 16),
            in_channels=1,
            growth_rate=args.densenet_growth_rate,
            init_features=args.densenet_init_features,
            bn_size=args.densenet_bn_size,
            drop_rate=args.densenet_drop_rate,
            compression=args.densenet_compression,
        )
    if backbone_name == "convnext_tiny":
        return ConvNeXtBackbone3D(
            in_channels=1,
            depths=tuple(args.convnext_depths),
            dims=tuple(args.convnext_dims),
            drop_path_rate=args.drop_path_rate,
            use_checkpoint=args.convnext_use_checkpoint,
        )
    if backbone_name == "swinunetr":
        return SwinUNETREncoderBackbone3D(
            in_channels=1,
            embed_dim=args.swin_embed_dim,
            patch_size=tuple(args.swin_patch_size),
            window_size=tuple(args.swin_window_size),
            depths=tuple(args.swin_depths),
            num_heads=tuple(args.swin_num_heads),
            use_checkpoint=args.swin_use_checkpoint,
            drop_path_rate=args.drop_path_rate,
        )
    raise ValueError(f"Unsupported backbone: {backbone_name}")


# -------------------------
# Clinical-guided modules and classifiers
# -------------------------


class MLPBlock(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, out_dim: int, dropout: float = 0.3) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class GroupClinicalEncoder(nn.Module):
    def __init__(
        self,
        group_embed_dim: int = 32,
        clinical_dim: int = 128,
        hidden_dim: int = 64,
        dropout: float = 0.3,
    ) -> None:
        super().__init__()
        self.idx = {group_name: [CLINICAL_COLUMNS.index(c) for c in cols] for group_name, cols in GROUPS.items()}
        self.mlp_demo = MLPBlock(4, hidden_dim, group_embed_dim, dropout=dropout)
        self.mlp_global = MLPBlock(4, hidden_dim, group_embed_dim, dropout=dropout)
        self.mlp_memory = MLPBlock(5, hidden_dim, group_embed_dim, dropout=dropout)
        self.mlp_func = MLPBlock(1, hidden_dim, group_embed_dim, dropout=dropout)
        self.fusion = nn.Sequential(
            nn.Linear(4 * group_embed_dim, clinical_dim),
            nn.LayerNorm(clinical_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(clinical_dim, clinical_dim),
            nn.LayerNorm(clinical_dim),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        demo = self.mlp_demo(x[:, self.idx["demo"]])
        global_cog = self.mlp_global(x[:, self.idx["global"]])
        memory = self.mlp_memory(x[:, self.idx["memory"]])
        func = self.mlp_func(x[:, self.idx["func"]])
        return self.fusion(torch.cat([demo, global_cog, memory, func], dim=1))


class PlainClinicalMLP(nn.Module):
    """Plain non-group-aware clinical encoder for late-fusion baselines."""

    def __init__(
        self,
        in_dim: int = len(CLINICAL_COLUMNS),
        clinical_dim: int = 256,
        hidden_dim: int = 128,
        dropout: float = 0.25,
    ) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, clinical_dim),
            nn.LayerNorm(clinical_dim),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class FiLM3D(nn.Module):
    def __init__(self, clinical_dim: int, feature_channels: int, hidden_dim: int = 128) -> None:
        super().__init__()
        self.feature_channels = feature_channels
        self.gamma = nn.Sequential(nn.Linear(clinical_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, feature_channels))
        self.beta = nn.Sequential(nn.Linear(clinical_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, feature_channels))
        nn.init.zeros_(self.gamma[-1].weight)
        nn.init.zeros_(self.gamma[-1].bias)
        nn.init.zeros_(self.beta[-1].weight)
        nn.init.zeros_(self.beta[-1].bias)

    def forward(self, f: torch.Tensor, e_clinical: torch.Tensor) -> torch.Tensor:
        gamma = self.gamma(e_clinical).view(-1, self.feature_channels, 1, 1, 1)
        beta = self.beta(e_clinical).view(-1, self.feature_channels, 1, 1, 1)
        return (1.0 + gamma) * f + beta


class ClinicalSpatialAttention3D(nn.Module):
    def __init__(self, clinical_dim: int, feature_channels: int, kernel_size: int = 3) -> None:
        super().__init__()
        hidden = max(feature_channels // 4, 8)
        padding = kernel_size // 2
        self.feature_channels = feature_channels
        self.clinical_proj = nn.Linear(clinical_dim, feature_channels)
        self.attention = nn.Sequential(
            nn.Conv3d(feature_channels, hidden, kernel_size=1, bias=False),
            nn.BatchNorm3d(hidden),
            nn.ReLU(inplace=True),
            nn.Conv3d(hidden, 1, kernel_size=kernel_size, padding=padding, bias=True),
        )
        nn.init.zeros_(self.attention[-1].weight)
        nn.init.zeros_(self.attention[-1].bias)

    def forward(self, f: torch.Tensor, e_clinical: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        c = self.clinical_proj(e_clinical).view(-1, self.feature_channels, 1, 1, 1)
        a = self.attention(f + c)
        return f * torch.sigmoid(a) + f, a


class MRIOnlyModel(nn.Module):
    def __init__(self, backbone: nn.Module, dropout: float, classifier_hidden_dim: int) -> None:
        super().__init__()
        self.backbone = backbone
        c4 = backbone.out_channels
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.classifier = nn.Sequential(
            nn.Linear(c4, classifier_hidden_dim),
            nn.LayerNorm(classifier_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(classifier_hidden_dim, 1),
        )

    def forward(self, x_mri: torch.Tensor, x_clinical: Optional[torch.Tensor] = None) -> torch.Tensor:
        f3 = self.backbone.forward_to_stage3(x_mri)
        f4 = self.backbone.forward_stage4(f3)
        z = self.pool(f4).flatten(1)
        return self.classifier(z).squeeze(1)

    def freeze_early_layers(self) -> None:
        if hasattr(self.backbone, "freeze_early_layers"):
            self.backbone.freeze_early_layers()

    def unfreeze_all(self) -> None:
        for p in self.parameters():
            p.requires_grad = True


class FullClinicalGuidedModel(nn.Module):
    def __init__(
        self,
        backbone: nn.Module,
        group_embed_dim: int,
        clinical_dim: int,
        clinical_hidden_dim: int,
        dropout: float,
        classifier_hidden_dim: int,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        c3 = backbone.stage3_channels
        c4 = backbone.out_channels
        self.clinical_encoder = GroupClinicalEncoder(
            group_embed_dim=group_embed_dim,
            clinical_dim=clinical_dim,
            hidden_dim=clinical_hidden_dim,
            dropout=dropout,
        )
        self.film3 = FiLM3D(clinical_dim, c3)
        self.spatial3 = ClinicalSpatialAttention3D(clinical_dim, c3, kernel_size=3)
        self.film4 = FiLM3D(clinical_dim, c4)
        self.spatial4 = ClinicalSpatialAttention3D(clinical_dim, c4, kernel_size=3)
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.classifier = nn.Sequential(
            nn.Linear(c4 + clinical_dim, classifier_hidden_dim),
            nn.LayerNorm(classifier_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(classifier_hidden_dim, 1),
        )

    def forward(self, x_mri: torch.Tensor, x_clinical: torch.Tensor) -> torch.Tensor:
        e = self.clinical_encoder(x_clinical)
        f3 = self.backbone.forward_to_stage3(x_mri)
        f3_film = self.film3(f3, e)
        f3_att, _ = self.spatial3(f3_film, e)
        f4 = self.backbone.forward_stage4(f3_att)
        f4_film = self.film4(f4, e)
        f4_att, _ = self.spatial4(f4_film, e)
        z_mri = self.pool(f4_att).flatten(1)
        return self.classifier(torch.cat([z_mri, e], dim=1)).squeeze(1)

    def freeze_early_layers(self) -> None:
        if hasattr(self.backbone, "freeze_early_layers"):
            self.backbone.freeze_early_layers()

    def unfreeze_all(self) -> None:
        for p in self.parameters():
            p.requires_grad = True


class LateFusionConcatMLPModel(nn.Module):
    """MRI pooled feature + clinical feature concatenation + MLP classifier."""

    def __init__(
        self,
        backbone: nn.Module,
        clinical_mode: str,
        clinical_dim: int,
        clinical_hidden_dim: int,
        dropout: float,
        classifier_hidden_dim: int,
    ) -> None:
        super().__init__()
        if clinical_mode not in {"raw", "mlp"}:
            raise ValueError("clinical_mode must be either 'raw' or 'mlp'.")
        self.backbone = backbone
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.clinical_mode = clinical_mode
        if clinical_mode == "raw":
            clinical_out_dim = len(CLINICAL_COLUMNS)
            self.clinical_encoder = nn.Identity()
        else:
            clinical_out_dim = clinical_dim
            self.clinical_encoder = PlainClinicalMLP(
                in_dim=len(CLINICAL_COLUMNS),
                clinical_dim=clinical_dim,
                hidden_dim=clinical_hidden_dim,
                dropout=dropout,
            )
        c4 = backbone.out_channels
        self.classifier = nn.Sequential(
            nn.Linear(c4 + clinical_out_dim, classifier_hidden_dim),
            nn.LayerNorm(classifier_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(classifier_hidden_dim, 1),
        )

    def forward(self, x_mri: torch.Tensor, x_clinical: torch.Tensor) -> torch.Tensor:
        f3 = self.backbone.forward_to_stage3(x_mri)
        f4 = self.backbone.forward_stage4(f3)
        z_mri = self.pool(f4).flatten(1)
        z_clinical = self.clinical_encoder(x_clinical)
        return self.classifier(torch.cat([z_mri, z_clinical], dim=1)).squeeze(1)

    def freeze_backbone(self) -> None:
        for p in self.backbone.parameters():
            p.requires_grad = False

    def freeze_early_layers(self) -> None:
        if hasattr(self.backbone, "freeze_early_layers"):
            self.backbone.freeze_early_layers()

    def unfreeze_all(self) -> None:
        for p in self.parameters():
            p.requires_grad = True


class GatedFusionModel(nn.Module):
    """Feature-level gated fusion without intermediate MRI feature modulation."""

    def __init__(
        self,
        backbone: nn.Module,
        group_embed_dim: int,
        clinical_dim: int,
        clinical_hidden_dim: int,
        dropout: float,
        classifier_hidden_dim: int,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        self.clinical_encoder = GroupClinicalEncoder(
            group_embed_dim=group_embed_dim,
            clinical_dim=clinical_dim,
            hidden_dim=clinical_hidden_dim,
            dropout=dropout,
        )
        c4 = backbone.out_channels
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.clinical_to_mri = nn.Sequential(
            nn.Linear(clinical_dim, classifier_hidden_dim),
            nn.LayerNorm(classifier_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(classifier_hidden_dim, c4),
        )
        self.gate_net = nn.Sequential(
            nn.Linear(c4 + clinical_dim, classifier_hidden_dim),
            nn.LayerNorm(classifier_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(classifier_hidden_dim, c4),
            nn.Sigmoid(),
        )
        self.classifier = nn.Sequential(
            nn.Linear(c4, classifier_hidden_dim),
            nn.LayerNorm(classifier_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(classifier_hidden_dim, 1),
        )

    def forward(self, x_mri: torch.Tensor, x_clinical: torch.Tensor) -> torch.Tensor:
        e = self.clinical_encoder(x_clinical)
        f3 = self.backbone.forward_to_stage3(x_mri)
        f4 = self.backbone.forward_stage4(f3)
        z_mri = self.pool(f4).flatten(1)
        z_clinical = self.clinical_to_mri(e)
        gate = self.gate_net(torch.cat([z_mri, e], dim=1))
        z_fused = gate * z_mri + (1.0 - gate) * z_clinical
        return self.classifier(z_fused).squeeze(1)

    def freeze_backbone(self) -> None:
        for p in self.backbone.parameters():
            p.requires_grad = False

    def freeze_early_layers(self) -> None:
        if hasattr(self.backbone, "freeze_early_layers"):
            self.backbone.freeze_early_layers()

    def unfreeze_all(self) -> None:
        for p in self.parameters():
            p.requires_grad = True


class LightweightCrossAttentionBlock(nn.Module):
    """Clinical-query cross-attention over Stage-4 MRI tokens."""

    def __init__(
        self,
        mri_channels: int,
        clinical_dim: int,
        attn_dim: int = 128,
        num_heads: int = 4,
        dropout: float = 0.25,
    ) -> None:
        super().__init__()
        if attn_dim % num_heads != 0:
            raise ValueError(f"attn_dim={attn_dim} must be divisible by num_heads={num_heads}")
        self.mri_proj = nn.Linear(mri_channels, attn_dim)
        self.clinical_query_proj = nn.Linear(clinical_dim, attn_dim)
        self.attn = nn.MultiheadAttention(attn_dim, num_heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(attn_dim)
        self.ffn = nn.Sequential(
            nn.Linear(attn_dim, attn_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(attn_dim * 2, attn_dim),
            nn.Dropout(dropout),
        )
        self.norm2 = nn.LayerNorm(attn_dim)

    def forward(self, f4: torch.Tensor, e_clinical: torch.Tensor) -> torch.Tensor:
        mri_tokens = f4.flatten(2).transpose(1, 2).contiguous()
        kv = self.mri_proj(mri_tokens)
        q = self.clinical_query_proj(e_clinical).unsqueeze(1)
        attn_out, _ = self.attn(q, kv, kv, need_weights=False)
        x = self.norm1(q + attn_out)
        x = self.norm2(x + self.ffn(x))
        return x.squeeze(1)


class LightweightCrossAttentionFusionModel(nn.Module):
    """Late MRI-clinical fusion using a clinical-query cross-attention token."""

    def __init__(
        self,
        backbone: nn.Module,
        group_embed_dim: int,
        clinical_dim: int,
        clinical_hidden_dim: int,
        dropout: float,
        classifier_hidden_dim: int,
        cross_attn_dim: int,
        cross_attn_heads: int,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        self.clinical_encoder = GroupClinicalEncoder(
            group_embed_dim=group_embed_dim,
            clinical_dim=clinical_dim,
            hidden_dim=clinical_hidden_dim,
            dropout=dropout,
        )
        c4 = backbone.out_channels
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.cross_attn = LightweightCrossAttentionBlock(
            mri_channels=c4,
            clinical_dim=clinical_dim,
            attn_dim=cross_attn_dim,
            num_heads=cross_attn_heads,
            dropout=dropout,
        )
        self.classifier = nn.Sequential(
            nn.Linear(c4 + clinical_dim + cross_attn_dim, classifier_hidden_dim),
            nn.LayerNorm(classifier_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(classifier_hidden_dim, 1),
        )

    def forward(self, x_mri: torch.Tensor, x_clinical: torch.Tensor) -> torch.Tensor:
        e = self.clinical_encoder(x_clinical)
        f3 = self.backbone.forward_to_stage3(x_mri)
        f4 = self.backbone.forward_stage4(f3)
        z_mri = self.pool(f4).flatten(1)
        z_cross = self.cross_attn(f4, e)
        return self.classifier(torch.cat([z_mri, e, z_cross], dim=1)).squeeze(1)

    def freeze_backbone(self) -> None:
        for p in self.backbone.parameters():
            p.requires_grad = False

    def freeze_early_layers(self) -> None:
        if hasattr(self.backbone, "freeze_early_layers"):
            self.backbone.freeze_early_layers()

    def unfreeze_all(self) -> None:
        for p in self.parameters():
            p.requires_grad = True


def build_model(mode: str, backbone_name: str, args: argparse.Namespace) -> nn.Module:
    backbone = build_backbone(backbone_name, args)
    if mode == "mri":
        return MRIOnlyModel(backbone, dropout=args.dropout, classifier_hidden_dim=args.classifier_hidden_dim)
    if mode == "full":
        return FullClinicalGuidedModel(
            backbone,
            group_embed_dim=args.group_embed_dim,
            clinical_dim=args.clinical_dim,
            clinical_hidden_dim=args.clinical_hidden_dim,
            dropout=args.dropout,
            classifier_hidden_dim=args.classifier_hidden_dim,
        )
    if mode == "late_concat_mlp":
        return LateFusionConcatMLPModel(
            backbone,
            clinical_mode=args.clinical_mode,
            clinical_dim=args.clinical_dim,
            clinical_hidden_dim=args.clinical_hidden_dim,
            dropout=args.dropout,
            classifier_hidden_dim=args.classifier_hidden_dim,
        )
    if mode == "gated_fusion":
        return GatedFusionModel(
            backbone,
            group_embed_dim=args.group_embed_dim,
            clinical_dim=args.clinical_dim,
            clinical_hidden_dim=args.clinical_hidden_dim,
            dropout=args.dropout,
            classifier_hidden_dim=args.classifier_hidden_dim,
        )
    if mode == "crossattn_fusion":
        return LightweightCrossAttentionFusionModel(
            backbone,
            group_embed_dim=args.group_embed_dim,
            clinical_dim=args.clinical_dim,
            clinical_hidden_dim=args.clinical_hidden_dim,
            dropout=args.dropout,
            classifier_hidden_dim=args.classifier_hidden_dim,
            cross_attn_dim=args.cross_attn_dim,
            cross_attn_heads=args.cross_attn_heads,
        )
    raise ValueError(f"Unsupported mode={mode}")


# -------------------------
# Metrics and training helpers
# -------------------------


def find_youden_threshold(labels: np.ndarray, probs: np.ndarray) -> float:
    labels = labels.astype(int)
    probs = probs.astype(float)
    if len(np.unique(labels)) < 2:
        return 0.5
    fpr, tpr, thresholds = roc_curve(labels, probs)
    finite = np.isfinite(thresholds)
    if not np.any(finite):
        return 0.5
    youden = tpr[finite] - fpr[finite]
    return float(thresholds[finite][int(np.argmax(youden))])


def compute_metrics(labels: np.ndarray, probs: np.ndarray, threshold: float = 0.5) -> Dict[str, float]:
    labels = labels.astype(int)
    probs = probs.astype(float)
    preds = (probs >= threshold).astype(int)
    acc = accuracy_score(labels, preds) if len(labels) else float("nan")
    f1 = f1_score(labels, preds, zero_division=0) if len(np.unique(labels)) > 1 else float("nan")
    try:
        auc = roc_auc_score(labels, probs) if len(np.unique(labels)) > 1 else float("nan")
    except Exception:
        auc = float("nan")
    tn, fp, fn, tp = confusion_matrix(labels, preds, labels=[0, 1]).ravel()
    sen = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spe = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    return {
        "ACC": float(acc),
        "AUC": float(auc),
        "SEN": float(sen),
        "SPE": float(spe),
        "BACC": float((sen + spe) / 2.0),
        "F1": float(f1),
        "TN": int(tn),
        "FP": int(fp),
        "FN": int(fn),
        "TP": int(tp),
    }


def make_pos_weight(train_df: pd.DataFrame, device: torch.device) -> torch.Tensor:
    labels = train_df["label"].astype(int).values
    pos = int((labels == 1).sum())
    neg = int((labels == 0).sum())
    weight = 1.0 if pos == 0 else neg / max(pos, 1)
    return torch.tensor([weight], dtype=torch.float32, device=device)


def get_amp_context(enabled: bool, device: torch.device):
    if enabled and device.type == "cuda":
        return torch.amp.autocast(device_type="cuda", enabled=True)
    return torch.amp.autocast(device_type="cpu", enabled=False)


def make_grad_scaler(amp: bool, device: torch.device):
    enabled = bool(amp and device.type == "cuda")
    try:
        return torch.amp.GradScaler("cuda", enabled=enabled)
    except TypeError:
        return torch.cuda.amp.GradScaler(enabled=enabled)


def run_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: Optional[torch.optim.Optimizer],
    criterion: nn.Module,
    device: torch.device,
    amp: bool,
    scaler,
    desc: str,
    threshold: float = 0.5,
    select_threshold_by_youden: bool = False,
) -> Tuple[float, Dict[str, float], pd.DataFrame]:
    is_train = optimizer is not None
    model.train(is_train)

    losses = []
    all_labels: List[float] = []
    all_probs: List[float] = []
    all_subjects: List[str] = []
    all_paths: List[str] = []

    pbar = tqdm(loader, desc=desc, leave=False)
    for batch in pbar:
        mri = batch["mri"].to(device, non_blocking=True)
        clinical = batch["clinical"].to(device, non_blocking=True)
        labels = batch["label"].to(device, non_blocking=True)

        if is_train:
            optimizer.zero_grad(set_to_none=True)

        with torch.set_grad_enabled(is_train):
            with get_amp_context(amp, device):
                logits = model(mri, clinical)
                loss = criterion(logits, labels)

            if is_train:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
                scaler.step(optimizer)
                scaler.update()

        probs = torch.sigmoid(logits.detach()).float().cpu().numpy()
        losses.append(float(loss.detach().cpu()))
        all_probs.extend(probs.tolist())
        all_labels.extend(labels.detach().cpu().numpy().tolist())
        all_subjects.extend(list(batch["subject_id"]))
        all_paths.extend(list(batch["mri_path"]))
        pbar.set_postfix({"loss": f"{np.mean(losses):.4f}"})

    labels_np = np.array(all_labels, dtype=np.float32)
    probs_np = np.array(all_probs, dtype=np.float32)
    if select_threshold_by_youden:
        threshold = find_youden_threshold(labels_np, probs_np)
    metrics = compute_metrics(labels_np, probs_np, threshold=threshold)
    metrics["threshold"] = float(threshold)
    avg_loss = float(np.mean(losses)) if losses else float("nan")

    pred_df = pd.DataFrame(
        {
            "Subject_ID": all_subjects,
            "mri_path": all_paths,
            "label": labels_np.astype(int),
            "prob_pmci": probs_np,
            "pred": (probs_np >= threshold).astype(int),
        }
    )
    return avg_loss, metrics, pred_df


def file_stem(mode: str, backbone_name: str) -> str:
    prefixes = {
        "mri": "mri",
        "full": "full_clinical_guided",
        "late_concat_mlp": "late_fusion_concat_mlp",
        "gated_fusion": "gated_fusion",
        "crossattn_fusion": "lightweight_crossattn_fusion",
    }
    return f"{prefixes.get(mode, mode)}_{backbone_name}"


def best_checkpoint_path(out_dir: Path, mode: str, backbone_name: str) -> Path:
    return out_dir / f"best_{file_stem(mode, backbone_name)}.pt"


def last_checkpoint_path(out_dir: Path, mode: str, backbone_name: str) -> Path:
    return out_dir / f"last_{file_stem(mode, backbone_name)}.pt"


def strip_module_prefix(state: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    out = {}
    for k, v in state.items():
        key = k[7:] if k.startswith("module.") else k
        out[key] = v
    return out


def extract_state_dict(ckpt: object) -> Dict[str, torch.Tensor]:
    if isinstance(ckpt, dict):
        state = ckpt.get("model_state_dict", ckpt.get("state_dict", ckpt))
    else:
        state = ckpt
    if not isinstance(state, dict):
        raise RuntimeError("Checkpoint does not contain a state dict.")
    return strip_module_prefix(state)


def load_mri_pretrained(model: nn.Module, ckpt_path: Path) -> None:
    print(f"[INIT] Loading MRI-only checkpoint from {ckpt_path}")
    ckpt = torch.load(ckpt_path, map_location="cpu")
    state = extract_state_dict(ckpt)
    model_state = model.state_dict()
    mapped_state = {}
    for k, v in state.items():
        if k in model_state and model_state[k].shape == v.shape:
            mapped_state[k] = v
        elif ("backbone." + k) in model_state and model_state["backbone." + k].shape == v.shape:
            mapped_state["backbone." + k] = v
        elif k.startswith("backbone.") and k in model_state and model_state[k].shape == v.shape:
            mapped_state[k] = v
    missing, unexpected = model.load_state_dict(mapped_state, strict=False)
    loaded_backbone = [k for k in mapped_state if k.startswith("backbone.")]
    print(f"[INIT] Loaded tensors: {len(mapped_state)} / {len(state)}")
    print(f"[INIT] Loaded backbone tensors: {len(loaded_backbone)}")
    print(f"[INIT] Missing keys after mapped load: {len(missing)}")
    print(f"[INIT] Unexpected keys after mapped load: {len(unexpected)}")
    if len(mapped_state) == 0:
        raise RuntimeError("No tensors were loaded from the pretrained MRI checkpoint.")


def apply_train_phase(model: nn.Module, epoch: int, args: argparse.Namespace) -> str:
    if getattr(args, "freeze_backbone", False) and hasattr(model, "freeze_backbone"):
        model.unfreeze_all()
        model.freeze_backbone()
        return "backbone_frozen"
    if args.warmup_freeze_epochs <= 0:
        model.unfreeze_all()
        return "all_trainable"
    if epoch <= args.warmup_freeze_epochs:
        model.unfreeze_all()
        model.freeze_early_layers()
        return "early_frozen"
    model.unfreeze_all()
    return "all_trainable"


def make_optimizer(model: nn.Module, lr: float, weight_decay: float) -> torch.optim.Optimizer:
    return torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=lr, weight_decay=weight_decay)


def save_training_checkpoint(
    path: Path,
    epoch: int,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler._LRScheduler,
    scaler,
    args: argparse.Namespace,
    backbone_name: str,
    mode: str,
    stats: Dict[str, Dict[str, float]],
    best_score: float,
    best_auc: float,
    best_epoch: int,
    no_improve: int,
    history_rows: List[Dict[str, object]],
    val_metrics: Dict[str, float],
    val_loss: float,
) -> None:
    torch.save(
        {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "scheduler_state_dict": scheduler.state_dict(),
            "scaler_state_dict": scaler.state_dict() if scaler is not None else None,
            "args": vars(args),
            "backbone": backbone_name,
            "mode": mode,
            "clinical_columns": CLINICAL_COLUMNS,
            "clinical_groups": GROUPS,
            "clinical_normalizer": stats,
            "best_score": best_score,
            "best_auc": best_auc,
            "best_epoch": best_epoch,
            "no_improve": no_improve,
            "history_rows": history_rows,
            "val_metrics": val_metrics,
            "val_loss": val_loss,
            "decision_threshold": val_metrics.get("threshold", 0.5),
        },
        path,
    )


def find_resume_path(args: argparse.Namespace, out_dir: Path, mode: str, backbone_name: str) -> Optional[Path]:
    if args.resume_checkpoint:
        return Path(args.resume_checkpoint)
    candidate = last_checkpoint_path(out_dir, mode, backbone_name)
    if args.auto_resume and candidate.exists():
        return candidate
    return None


def restore_resume_state(
    resume_path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler._LRScheduler,
    scaler,
    device: torch.device,
) -> Tuple[int, float, float, int, int, List[Dict[str, object]]]:
    print(f"[RESUME] Loading checkpoint from {resume_path}")
    ckpt = torch.load(resume_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    try:
        optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        scheduler.load_state_dict(ckpt["scheduler_state_dict"])
        if scaler is not None and ckpt.get("scaler_state_dict") is not None:
            scaler.load_state_dict(ckpt["scaler_state_dict"])
        print("[RESUME] Optimizer, scheduler, and scaler restored.")
    except Exception as exc:
        print(f"[RESUME] Could not restore optimizer/scheduler state; continuing with fresh optimizer. Reason: {exc}")
    start_epoch = int(ckpt.get("epoch", 0)) + 1
    best_score = float(ckpt.get("best_score", -math.inf))
    best_auc = float(ckpt.get("best_auc", -math.inf))
    best_epoch = int(ckpt.get("best_epoch", 0))
    no_improve = int(ckpt.get("no_improve", 0))
    history_rows = list(ckpt.get("history_rows", []))
    print(f"[RESUME] Resuming from epoch {start_epoch}; best_epoch={best_epoch}, best_score={best_score:.4f}.")
    return start_epoch, best_score, best_auc, best_epoch, no_improve, history_rows


def train(args: argparse.Namespace, backbone_name: str, mode: str) -> None:
    seed_everything(args.seed)
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)
    save_json(vars(args), out_dir / "args.json")

    manifest = build_manifest(Path(args.mri_dir), Path(args.clinical_csv), out_dir, max_samples=args.max_samples)
    train_df_raw, val_df_raw, test_df_raw = split_manifest(
        manifest,
        out_dir=out_dir,
        fold=args.fold,
        n_splits=args.n_splits,
        seed=args.seed,
        use_csv_split=not args.ignore_csv_split,
        val_size=args.val_size,
    )

    stats = fit_clinical_normalizer(train_df_raw)
    save_json(stats, out_dir / "clinical_normalizer_train_split.json")
    train_df = apply_clinical_normalizer(train_df_raw, stats)
    val_df = apply_clinical_normalizer(val_df_raw, stats)
    test_df = apply_clinical_normalizer(test_df_raw, stats) if test_df_raw is not None and len(test_df_raw) > 0 else None

    selected_clinical_columns = validate_selected_clinical_columns(getattr(args, "selected_clinical_columns", None))
    if selected_clinical_columns:
        masked_clinical_columns = [c for c in CLINICAL_COLUMNS if c not in selected_clinical_columns]
        train_df = mask_unselected_clinical_columns(train_df, selected_clinical_columns)
        val_df = mask_unselected_clinical_columns(val_df, selected_clinical_columns)
        test_df = mask_unselected_clinical_columns(test_df, selected_clinical_columns) if test_df is not None else None
        save_json(
            {
                "selected_clinical_columns": selected_clinical_columns,
                "masked_clinical_columns": masked_clinical_columns,
                "note": "Unselected variables are set to zero after train-split normalization; model input dimension remains unchanged.",
            },
            out_dir / "selected_clinical_columns.json",
        )
        print(f"[CLINICAL] Selected variables: {selected_clinical_columns}")
        print(f"[CLINICAL] Masked variables: {masked_clinical_columns}")

    train_df.to_csv(out_dir / "manifest_train_normalized.csv", index=False, encoding="utf-8-sig")
    val_df.to_csv(out_dir / "manifest_val_normalized.csv", index=False, encoding="utf-8-sig")
    if test_df is not None:
        test_df.to_csv(out_dir / "manifest_test_normalized.csv", index=False, encoding="utf-8-sig")

    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    print(f"[DEVICE] {device}")
    if device.type == "cuda":
        print(f"[DEVICE] GPU: {torch.cuda.get_device_name(0)}")

    target_shape = tuple(args.target_shape)
    train_ds = MRICLClinicalDataset(train_df, target_shape=target_shape, augment=args.augment)
    val_ds = MRICLClinicalDataset(val_df, target_shape=target_shape, augment=False)
    test_ds = MRICLClinicalDataset(test_df, target_shape=target_shape, augment=False) if test_df is not None else None
    loader_kwargs = {
        "num_workers": args.num_workers,
        "pin_memory": device.type == "cuda",
        "persistent_workers": args.num_workers > 0,
        "drop_last": False,
    }
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, **loader_kwargs)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, **loader_kwargs)
    test_loader = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False, **loader_kwargs) if test_ds is not None else None

    model = build_model(mode, backbone_name, args).to(device)
    print(f"[MODEL] mode={mode}, backbone={backbone_name}")
    print(f"[MODEL] trainable parameters before phase setup: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

    if mode != "mri" and args.pretrained_mri_checkpoint:
        load_mri_pretrained(model, Path(args.pretrained_mri_checkpoint))

    phase = apply_train_phase(model, 1, args)
    print(f"[TRAIN] Initial phase: {phase}")
    print(f"[MODEL] trainable parameters after phase setup: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

    current_lr = args.lr if phase == "early_frozen" else args.lr * (args.unfreeze_lr_factor if args.warmup_freeze_epochs > 0 and mode == "full" else 1.0)
    optimizer = make_optimizer(model, current_lr, args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(args.epochs, 1), eta_min=args.min_lr)
    scaler = make_grad_scaler(args.amp, device)

    pos_weight = make_pos_weight(train_df, device) if args.class_weight else torch.tensor([1.0], device=device)
    print(f"[LOSS] BCEWithLogitsLoss pos_weight={float(pos_weight.item()):.4f}")
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    start_epoch = 1
    best_score = -math.inf
    best_auc = -math.inf
    best_epoch = 0
    no_improve = 0
    history_rows: List[Dict[str, object]] = []

    resume_path = find_resume_path(args, out_dir, mode, backbone_name)
    if resume_path is not None and resume_path.exists():
        start_epoch, best_score, best_auc, best_epoch, no_improve, history_rows = restore_resume_state(
            resume_path, model, optimizer, scheduler, scaler, device
        )
    elif resume_path is not None:
        print(f"[RESUME] Requested resume checkpoint does not exist: {resume_path}")

    current_phase = apply_train_phase(model, start_epoch, args)
    if current_phase != phase:
        print(f"[TRAIN] Phase at resumed start epoch {start_epoch}: {current_phase}; rebuilding optimizer.")
        lr = args.lr * args.unfreeze_lr_factor if current_phase == "all_trainable" and args.warmup_freeze_epochs > 0 else args.lr
        optimizer = make_optimizer(model, lr, args.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(args.epochs - start_epoch + 1, 1), eta_min=args.min_lr
        )
        phase = current_phase

    best_path = best_checkpoint_path(out_dir, mode, backbone_name)
    last_path = last_checkpoint_path(out_dir, mode, backbone_name)

    for epoch in range(start_epoch, args.epochs + 1):
        t0 = time.time()
        new_phase = apply_train_phase(model, epoch, args)
        if new_phase != phase:
            phase = new_phase
            lr = args.lr * args.unfreeze_lr_factor if phase == "all_trainable" and args.warmup_freeze_epochs > 0 else args.lr
            optimizer = make_optimizer(model, lr, args.weight_decay)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer, T_max=max(args.epochs - epoch + 1, 1), eta_min=args.min_lr
            )
            print(f"[TRAIN] Phase changed to {phase}; optimizer rebuilt with lr={lr:g}.")

        train_loss, train_metrics, _ = run_one_epoch(
            model, train_loader, optimizer, criterion, device, args.amp, scaler, desc=f"Epoch {epoch:03d} train"
        )
        val_loss, val_metrics, val_pred_df = run_one_epoch(
            model,
            val_loader,
            None,
            criterion,
            device,
            args.amp,
            None,
            desc=f"Epoch {epoch:03d} val",
            select_threshold_by_youden=True,
        )
        scheduler.step()
        seconds = time.time() - t0
        val_pred_df.to_csv(out_dir / "val_predictions_latest.csv", index=False, encoding="utf-8-sig")

        current_auc = val_metrics["AUC"]
        current_score = current_auc if np.isfinite(current_auc) else val_metrics["ACC"]
        improved = current_score > best_score
        if improved:
            best_score = float(current_score)
            best_auc = float(current_auc)
            best_epoch = epoch
            no_improve = 0
            save_training_checkpoint(
                best_path,
                epoch,
                model,
                optimizer,
                scheduler,
                scaler,
                args,
                backbone_name,
                mode,
                stats,
                best_score,
                best_auc,
                best_epoch,
                no_improve,
                history_rows,
                val_metrics,
                val_loss,
            )
            val_pred_df.to_csv(out_dir / "val_predictions_best.csv", index=False, encoding="utf-8-sig")
        else:
            no_improve += 1

        row = {
            "epoch": epoch,
            "phase": phase,
            "lr": optimizer.param_groups[0]["lr"],
            "train_loss": train_loss,
            "val_loss": val_loss,
            "seconds": seconds,
            "best_epoch": best_epoch,
        }
        for prefix, metrics in [("train", train_metrics), ("val", val_metrics)]:
            for k, v in metrics.items():
                row[f"{prefix}_{k}"] = v
        history_rows.append(row)
        pd.DataFrame(history_rows).to_csv(out_dir / "history.csv", index=False, encoding="utf-8-sig")

        save_training_checkpoint(
            last_path,
            epoch,
            model,
            optimizer,
            scheduler,
            scaler,
            args,
            backbone_name,
            mode,
            stats,
            best_score,
            best_auc,
            best_epoch,
            no_improve,
            history_rows,
            val_metrics,
            val_loss,
        )

        print(
            f"Epoch {epoch:03d}/{args.epochs} | "
            f"train loss {train_loss:.4f} ACC {train_metrics['ACC']:.3f} AUC {train_metrics['AUC']:.3f} | "
            f"val loss {val_loss:.4f} ACC {val_metrics['ACC']:.3f} AUC {val_metrics['AUC']:.3f} "
            f"SEN {val_metrics['SEN']:.3f} SPE {val_metrics['SPE']:.3f} BACC {val_metrics['BACC']:.3f} "
            f"F1 {val_metrics['F1']:.3f} THR {val_metrics['threshold']:.4f} | "
            f"best epoch {best_epoch} best score {best_score:.4f} | {seconds:.1f}s"
        )

        if args.early_stop_patience > 0 and no_improve >= args.early_stop_patience:
            print(f"[EARLY STOP] No improvement for {no_improve} epoch(s).")
            break

    print("[DONE] Training finished.")
    print(f"[DONE] Best epoch: {best_epoch}")
    print(f"[DONE] Best validation AUC: {best_auc}")
    print(f"[DONE] Best checkpoint: {best_path}")
    print(f"[DONE] Last checkpoint: {last_path}")
    print(f"[DONE] Output dir: {out_dir}")

    if test_loader is not None and best_path.exists():
        best_ckpt = torch.load(best_path, map_location=device)
        model.load_state_dict(best_ckpt["model_state_dict"])
        best_threshold = float(best_ckpt.get("decision_threshold", 0.5))
        test_loss, test_metrics, test_pred_df = run_one_epoch(
            model, test_loader, None, criterion, device, args.amp, None, desc="test", threshold=best_threshold
        )
        test_pred_df.to_csv(out_dir / "test_predictions_best.csv", index=False, encoding="utf-8-sig")
        save_json({"test_loss": test_loss, **test_metrics}, out_dir / "test_metrics_best.json")
        print(
            f"[TEST] loss {test_loss:.4f} ACC {test_metrics['ACC']:.3f} AUC {test_metrics['AUC']:.3f} "
            f"SEN {test_metrics['SEN']:.3f} SPE {test_metrics['SPE']:.3f} BACC {test_metrics['BACC']:.3f} "
            f"F1 {test_metrics['F1']:.3f} THR {test_metrics['threshold']:.4f}"
        )


def parse_args(backbone_name: str, mode: str) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Train {mode} model with {backbone_name} backbone.")
    parser.add_argument("--mri_dir", type=str, required=True, help="Directory containing preprocessed .nii.gz MRI files.")
    parser.add_argument("--clinical_csv", type=str, required=True, help="Clinical CSV with Subject_ID, outcome, and clinical variables.")
    parser.add_argument("--out_dir", type=str, required=True, help="Output directory.")
    parser.add_argument("--fold", type=int, default=0)
    parser.add_argument("--n_splits", type=int, default=5)
    parser.add_argument("--ignore_csv_split", action="store_true", help="Ignore split column and use StratifiedKFold.")
    parser.add_argument("--val_size", type=float, default=0.2)
    parser.add_argument("--max_samples", type=int, default=None)
    parser.add_argument("--target_shape", type=int, nargs=3, default=[169, 208, 179])

    parser.add_argument("--group_embed_dim", type=int, default=64)
    parser.add_argument("--clinical_dim", type=int, default=256)
    parser.add_argument("--clinical_hidden_dim", type=int, default=128)
    parser.add_argument("--classifier_hidden_dim", type=int, default=256)
    parser.add_argument("--dropout", type=float, default=0.25)
    parser.add_argument("--clinical_mode", type=str, default="mlp", choices=["raw", "mlp"])
    parser.add_argument("--cross_attn_dim", type=int, default=128)
    parser.add_argument("--cross_attn_heads", type=int, default=4)
    parser.add_argument(
        "--selected_clinical_columns",
        type=str,
        nargs="*",
        default=None,
        help=(
            "Optional clinical variables to keep. Unselected variables are zero-masked after normalization "
            "while preserving the original 14-D clinical input."
        ),
    )

    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--batch_size", type=int, default=2)
    parser.add_argument("--lr", type=float, default=5e-5)
    parser.add_argument("--min_lr", type=float, default=5e-7)
    parser.add_argument("--weight_decay", type=float, default=2e-4)
    parser.add_argument("--class_weight", action="store_true", default=True)
    parser.add_argument("--no_class_weight", action="store_false", dest="class_weight")
    parser.add_argument("--early_stop_patience", type=int, default=10)
    parser.add_argument("--warmup_freeze_epochs", type=int, default=0 if mode == "mri" else 3)
    parser.add_argument("--unfreeze_lr_factor", type=float, default=0.7)
    parser.add_argument("--freeze_backbone", action="store_true", help="Freeze the MRI backbone after loading the MRI-only checkpoint.")

    parser.add_argument("--num_workers", type=int, default=8)
    parser.add_argument("--amp", action="store_true")
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--augment", action="store_true")
    parser.add_argument("--seed", type=int, default=42)

    parser.add_argument("--pretrained_mri_checkpoint", type=str, default="", help="Full model only: MRI-only checkpoint for initialization.")
    parser.add_argument("--resume_checkpoint", type=str, default="", help="Explicit last/best checkpoint to resume from.")
    parser.add_argument("--auto_resume", action="store_true", default=True, help="Resume from last checkpoint in out_dir when present.")
    parser.add_argument("--no_auto_resume", action="store_false", dest="auto_resume")

    parser.add_argument("--resnet_base_channels", type=int, default=64)
    parser.add_argument("--densenet_growth_rate", type=int, default=32)
    parser.add_argument("--densenet_init_features", type=int, default=64)
    parser.add_argument("--densenet_bn_size", type=int, default=4)
    parser.add_argument("--densenet_drop_rate", type=float, default=0.0)
    parser.add_argument("--densenet_compression", type=float, default=0.5)

    parser.add_argument("--convnext_dims", type=int, nargs=4, default=[48, 96, 192, 384])
    parser.add_argument("--convnext_depths", type=int, nargs=4, default=[3, 3, 9, 3])
    parser.add_argument("--convnext_use_checkpoint", action="store_true")
    parser.add_argument("--drop_path_rate", type=float, default=0.1)

    parser.add_argument("--swin_embed_dim", type=int, default=24)
    parser.add_argument("--swin_patch_size", type=int, nargs=3, default=[4, 4, 4])
    parser.add_argument("--swin_window_size", type=int, nargs=3, default=[7, 7, 7])
    parser.add_argument("--swin_depths", type=int, nargs=4, default=[2, 2, 2, 2])
    parser.add_argument("--swin_num_heads", type=int, nargs=4, default=[3, 6, 12, 24])
    parser.add_argument("--swin_use_checkpoint", action="store_true", default=True)
    parser.add_argument("--no_swin_use_checkpoint", action="store_false", dest="swin_use_checkpoint")

    args = parser.parse_args()
    args.backbone = backbone_name
    args.mode = mode
    return args


def main(backbone_name: str, mode: str) -> None:
    if backbone_name not in BACKBONE_CHOICES:
        raise ValueError(f"Unsupported backbone_name={backbone_name}")
    allowed_modes = {"mri", "full", "late_concat_mlp", "gated_fusion", "crossattn_fusion"}
    if mode not in allowed_modes:
        raise ValueError(f"mode must be one of {sorted(allowed_modes)}")
    warnings.filterwarnings("ignore", category=UserWarning)
    args = parse_args(backbone_name, mode)
    train(args, backbone_name=backbone_name, mode=mode)
