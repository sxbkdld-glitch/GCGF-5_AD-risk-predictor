# MRI Preprocessing Workflow

This document describes the MRI preprocessing expected by the GCGF-5 deployment.

## Final MRI Input Required by the App

The deployed app expects a preprocessed baseline T1 MRI volume:

```text
format: .nii or .nii.gz
shape: 169 x 208 x 179
space: MNI152 template space
```

The app performs non-zero voxel z-score normalization at inference time. It does not perform skull stripping, registration, or cropping from raw MRI.

## Recommended Preprocessing Pipeline

### Step 1. ADNI Standard MRI Corrections

Use the ADNI corrected T1 MRI when available. The ADNI preprocessing corrections include:

1. **GradWarp correction**
   - Corrects gradient nonlinearity-related geometric distortion.

2. **B1 correction**
   - Corrects B1 field-related intensity non-uniformity.

3. **N3 intensity correction**
   - Corrects low-frequency intensity non-uniformity.

These ADNI correction steps produce a standardized starting T1 MRI for subsequent project-specific preprocessing.

### Step 2. N4 Bias Field Correction

Apply **N4 bias field correction** to further reduce residual intensity inhomogeneity.

Output:

```text
N4-corrected T1 MRI
```

### Step 3. Skull Stripping with HD-BET

Use **HD-BET** for brain extraction / skull stripping.

Output:

```text
skull-stripped brain MRI
brain mask
```

Manual quality control is recommended because failed skull stripping can strongly affect downstream prediction.

### Step 4. SynthMorph Registration to MNI152

Register the skull-stripped T1 MRI to the **MNI152 template** using **SynthMorph**.

Output:

```text
T1 MRI in MNI152 template space
```

The deployment assumes that inference MRI files are aligned to the same template space as the training data.

### Step 5. Crop to Model Input Size

Crop the registered MNI152-space MRI to:

```text
169 x 208 x 179
```

The cropped field of view should match the model training data.

### Step 6. Save Final NIfTI

Save the final volume as:

```text
*.nii.gz
```

Example final filename:

```text
subject001_T1_ADNIcorr_N4_HDBET_SynthMorph_MNI152_crop_169x208x179.nii.gz
```

## Inference-Time Normalization

During inference, the Streamlit app loads the NIfTI volume and applies non-zero voxel z-score normalization:

```text
x_norm = (x - mean(nonzero_voxels)) / std(nonzero_voxels)
```

Background voxels remain zero.

## Important Notes

- The app is designed for already-preprocessed NIfTI files.
- Do not upload raw DICOM files to the app.
- Do not upload patient-identifiable MRI files to a public GitHub repository.
- If the image shape differs from `169 x 208 x 179`, the app can resize it, but exact preprocessing consistency is preferred.
- For best reproducibility, use the same preprocessing pipeline for training, validation, and deployment images.

